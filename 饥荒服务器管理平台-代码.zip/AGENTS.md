# 饥荒服务器管理系统 (DST Manager)

## 应用概览

基于 NestJS + React + PostgreSQL 的饥荒联机版（Don't Starve Together）服务器管理后台。提供用户权限、集群管理、世界配置、Mod 管理、玩家管理、控制台命令、日志查看、监控图表、系统设置等完整功能。

## 技术架构

- **后端**: NestJS 10 + Drizzle ORM + PostgreSQL
- **前端**: React 19 + Tailwind CSS + shadcn/ui + React Router v6
- **图表**: ReactECharts
- **图标**: lucide-react

## 设计规范

### 色彩系统
- 主色：深紫色系（饥荒游戏暗黑哥特风格）
  - primary: hsl(262, 70%, 55%)
  - primary-foreground: hsl(0, 0%, 100%)
- 背景：深色主题
  - background: hsl(222, 47%, 11%)
  - foreground: hsl(210, 40%, 98%)
  - card: hsl(222, 47%, 15%)
  - card-foreground: hsl(210, 40%, 98%)
  - muted: hsl(222, 47%, 20%)
  - muted-foreground: hsl(215, 20%, 65%)
  - border: hsl(222, 47%, 25%)
- 状态色
  - success/online: hsl(142, 70%, 45%)
  - warning: hsl(38, 92%, 50%)
  - danger/offline: hsl(0, 84%, 60%)

### 排版
- 字体：系统默认 sans-serif
- 标题：font-semibold，层级清晰
- 正文：text-sm 为主，数据密集型管理后台

### 布局
- 侧边栏导航（左侧固定，240px 宽）+ 主内容区
- 内容区内边距：p-6
- 卡片间距：gap-4
- 圆角：rounded-lg
- 阴影：适度，深色主题下不明显

### 间距基线
- 区块间距：gap-6
- 卡片内边距：p-5
- 表单字段间距：gap-3
- 列表项间距：gap-2

## 模块清单

| 模块名 (kebab-case) | 页面组件名 | 路由 | 说明 |
|---------------------|-----------|------|------|
| auth | LoginPage | /login | 登录/注册 |
| dashboard | DashboardPage | / | 仪表盘概览 |
| clusters | ClustersPage | /clusters | 集群/服务器列表管理 |
| world-config | WorldConfigPage | /world-config | 世界配置管理 |
| mods | ModsPage | /mods | Mod 管理 |
| players | PlayersPage | /players | 玩家管理 |
| console | ConsolePage | /console | 控制台命令 |
| logs | LogsPage | /logs | 服务器日志 |
| monitoring | MonitoringPage | /monitoring | 监控图表 |
| settings | SettingsPage | /settings | 系统设置 |

## 数据库表

- dst_users - 用户表（ID、用户名、密码哈希、角色、创建时间）
- dst_clusters - 集群表（ID、名称、描述、状态、游戏模式、人数上限、洞穴开关、令牌、创建人）
- dst_servers - 服务器实例表（ID、集群ID、类型 master/caves、端口、PID、运行状态、最后心跳、内存占用）
- dst_world_config - 世界配置表（集群ID关联，世界大小、季节长度、资源丰度等 JSON 配置）
- dst_mods - Mod 表（ID、集群ID、创意工坊ID、名称、描述、启用状态、配置 JSON、排序优先级）
- dst_players - 玩家表（ID、集群ID、Klei ID、玩家名、是否在线、加入时间、游戏时长、角色）
- dst_player_lists - 玩家名单表（admin/whitelist/ban + 玩家信息 + 原因）
- dst_console_commands - 控制台命令历史表
- dst_server_logs - 服务器日志表
- dst_monitoring_stats - 监控统计数据表（在线人数、内存、时间戳）
- dst_system_settings - 系统设置表（Steam 令牌、备份配置等）

## 角色权限

- admin（管理员）：所有模块的读写权限
- user（普通用户）：只读权限（查看列表、状态、日志、监控），不可执行启停/修改/控制台命令
