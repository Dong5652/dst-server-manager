import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  User,
} from '@shared/api.interface';
import { setToken } from './_utils';

const MODULE = 'auth';

export async function login(data: LoginRequest): Promise<LoginResponse> {
  try {
    const res = await axiosForBackend.post<LoginResponse>('/api/auth/login', data);
    if (res.data?.token) {
      setToken(res.data.token);
    }
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] login failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function register(data: RegisterRequest): Promise<User> {
  try {
    const res = await axiosForBackend.post<User>('/api/auth/register', data);
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] register failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function me(token: string): Promise<User> {
  try {
    const res = await axiosForBackend.get<User>('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] me failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}
