import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ConsoleCommand,
  ExecuteCommandRequest,
} from '@shared/api.interface';

export async function execute(
  data: ExecuteCommandRequest,
): Promise<ConsoleCommand> {
  logger.info(`Executing command on cluster ${data.clusterId}`);
  const res = await axiosForBackend.post<ConsoleCommand>(
    '/api/console/execute',
    data,
  );
  return res.data;
}

export async function history(params: {
  clusterId: string;
  limit?: number;
}): Promise<ConsoleCommand[]> {
  const res = await axiosForBackend.get<{ items: ConsoleCommand[] }>(
    `/api/console/history`,
    { params },
  );
  return res.data.items;
}
