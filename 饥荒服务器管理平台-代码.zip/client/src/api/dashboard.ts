import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { DashboardStats } from '@shared/api.interface';
import { getAuthHeaders } from './_utils';

const MODULE = 'dashboard';

export async function getStats(): Promise<DashboardStats> {
  try {
    const res = await axiosForBackend.get<DashboardStats>('/api/dashboard/stats', {
      headers: getAuthHeaders(),
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] getStats failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}
