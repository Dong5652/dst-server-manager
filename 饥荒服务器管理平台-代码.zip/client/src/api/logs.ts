import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { ServerLog } from '@shared/api.interface';

export async function list(params: {
  clusterId: string;
  serverType?: 'master' | 'caves' | 'all';
  logLevel?: 'info' | 'warn' | 'error' | 'debug' | 'all';
  keyword?: string;
  limit?: number;
}): Promise<ServerLog[]> {
  const res = await axiosForBackend.get<{ items: ServerLog[] }>(
    '/api/logs',
    { params },
  );
  return res.data.items;
}
