import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { Cluster, CreateClusterRequest } from '@shared/api.interface';

export async function list(): Promise<Cluster[]> {
  const res = await axiosForBackend.get<{ items: Cluster[]; total: number }>(
    '/api/clusters',
  );
  return res.data.items;
}

export async function create(data: CreateClusterRequest): Promise<Cluster> {
  const res = await axiosForBackend.post<Cluster>('/api/clusters', data);
  return res.data;
}

export async function start(id: string): Promise<Cluster> {
  logger.info(`Starting cluster ${id}`);
  const res = await axiosForBackend.post<Cluster>(`/api/clusters/${id}/start`);
  return res.data;
}

export async function stop(id: string): Promise<Cluster> {
  logger.info(`Stopping cluster ${id}`);
  const res = await axiosForBackend.post<Cluster>(`/api/clusters/${id}/stop`);
  return res.data;
}

export async function restart(id: string): Promise<Cluster> {
  logger.info(`Restarting cluster ${id}`);
  const res = await axiosForBackend.post<Cluster>(
    `/api/clusters/${id}/restart`,
  );
  return res.data;
}

export async function remove(id: string): Promise<void> {
  await axiosForBackend.delete(`/api/clusters/${id}`);
}
