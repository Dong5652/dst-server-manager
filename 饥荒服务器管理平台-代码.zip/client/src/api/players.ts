import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Player,
  PlayerListEntry,
  AddPlayerListRequest,
} from '@shared/api.interface';
import { getAuthHeaders } from './_utils';

const MODULE = 'players';

export async function list(params: {
  clusterId: string;
  onlineOnly?: boolean;
}): Promise<Player[]> {
  try {
    const res = await axiosForBackend.get<Player[]>('/api/players', {
      headers: getAuthHeaders(),
      params,
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] list failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function getLists(params: {
  clusterId: string;
  listType: 'admin' | 'whitelist' | 'ban';
}): Promise<PlayerListEntry[]> {
  try {
    const res = await axiosForBackend.get<PlayerListEntry[]>('/api/players/lists', {
      headers: getAuthHeaders(),
      params,
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] getLists failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function addToList(data: AddPlayerListRequest): Promise<PlayerListEntry> {
  try {
    const res = await axiosForBackend.post<PlayerListEntry>(
      '/api/players/lists',
      data,
      { headers: getAuthHeaders() },
    );
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] addToList failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function removeFromList(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/players/lists/${id}`, {
      headers: getAuthHeaders(),
    });
  } catch (err) {
    logger.error(`[API:${MODULE}] removeFromList failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function kick(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/players/${id}/kick`, undefined, {
      headers: getAuthHeaders(),
    });
  } catch (err) {
    logger.error(`[API:${MODULE}] kick failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}
