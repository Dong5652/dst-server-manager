import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  MonitoringOverview,
  MonitoringStat,
} from '@shared/api.interface';

export async function overview(clusterId: string): Promise<MonitoringOverview> {
  const res = await axiosForBackend.get<MonitoringOverview>(
    `/api/monitoring/${clusterId}/overview`,
  );
  return res.data;
}

export async function history(params: {
  clusterId: string;
  hours?: number;
}): Promise<MonitoringStat[]> {
  const res = await axiosForBackend.get<{ items: MonitoringStat[] }>(
    `/api/monitoring/history`,
    { params },
  );
  return res.data.items;
}
