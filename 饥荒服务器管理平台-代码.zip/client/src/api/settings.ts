import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  SystemSetting,
  BackupEntry,
  CreateBackupResponse,
} from '@shared/api.interface';

export async function list(): Promise<SystemSetting[]> {
  const res = await axiosForBackend.get<{ items: SystemSetting[] }>(
    '/api/settings',
  );
  return res.data.items;
}

export async function update(
  settingKey: string,
  settingValue: string | number | boolean,
): Promise<SystemSetting> {
  logger.info(`Updating setting ${settingKey}`);
  const res = await axiosForBackend.patch<SystemSetting>(
    `/api/settings/${settingKey}`,
    { settingValue },
  );
  return res.data;
}

export async function createBackup(): Promise<CreateBackupResponse> {
  logger.info('Creating backup');
  const res = await axiosForBackend.post<CreateBackupResponse>(
    '/api/settings/backup',
  );
  return res.data;
}

export async function getBackups(): Promise<BackupEntry[]> {
  const res = await axiosForBackend.get<BackupEntry[]>(
    '/api/settings/backups',
  );
  return Array.isArray(res.data) ? res.data : [];
}
