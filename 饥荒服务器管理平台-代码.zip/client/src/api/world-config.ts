import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  WorldConfig,
  UpdateWorldConfigRequest,
} from '@shared/api.interface';
import { getAuthHeaders } from './_utils';

const MODULE = 'world-config';

export async function get(clusterId: string): Promise<WorldConfig> {
  try {
    const res = await axiosForBackend.get<WorldConfig>(`/api/world-config/${clusterId}`, {
      headers: getAuthHeaders(),
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] get failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function update(
  clusterId: string,
  data: UpdateWorldConfigRequest,
): Promise<WorldConfig> {
  try {
    const res = await axiosForBackend.put<WorldConfig>(
      `/api/world-config/${clusterId}`,
      data,
      { headers: getAuthHeaders() },
    );
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] update failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}
