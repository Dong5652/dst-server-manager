import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Mod,
  AddModRequest,
  UpdateModRequest,
} from '@shared/api.interface';
import { getAuthHeaders } from './_utils';

const MODULE = 'mods';

export async function list(clusterId: string): Promise<Mod[]> {
  try {
    const res = await axiosForBackend.get<Mod[]>('/api/mods', {
      headers: getAuthHeaders(),
      params: { clusterId },
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] list failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function add(data: AddModRequest): Promise<Mod> {
  try {
    const res = await axiosForBackend.post<Mod>('/api/mods', data, {
      headers: getAuthHeaders(),
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] add failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function update(id: string, data: UpdateModRequest): Promise<Mod> {
  try {
    const res = await axiosForBackend.patch<Mod>(`/api/mods/${id}`, data, {
      headers: getAuthHeaders(),
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] update failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function remove(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/mods/${id}`, {
      headers: getAuthHeaders(),
    });
  } catch (err) {
    logger.error(`[API:${MODULE}] remove failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function toggle(id: string): Promise<Mod> {
  try {
    const res = await axiosForBackend.post<Mod>(`/api/mods/${id}/toggle`, undefined, {
      headers: getAuthHeaders(),
    });
    return res.data;
  } catch (err) {
    logger.error(`[API:${MODULE}] toggle failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}

export async function reorder(clusterId: string, orderedIds: string[]): Promise<void> {
  try {
    await axiosForBackend.post(
      '/api/mods/reorder',
      { clusterId, orderedIds },
      { headers: getAuthHeaders() },
    );
  } catch (err) {
    logger.error(`[API:${MODULE}] reorder failed: ${(err as Error)?.message ?? String(err)}`);
    throw err;
  }
}
