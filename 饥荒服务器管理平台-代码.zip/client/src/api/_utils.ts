import { logger } from '@lark-apaas/client-toolkit/logger';

const TOKEN_KEY = 'dst_manager_token';

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch (err) {
    logger.error('Failed to save token', err as Error);
  }
}

export function removeToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch (err) {
    logger.error('Failed to remove token', err as Error);
  }
}

export function getAuthHeaders(): Record<string, string> {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function logApiError(module: string, method: string, error: unknown): void {
  logger.error(`[API:${module}] ${method} failed: ${(error as Error)?.message ?? String(error)}`);
}
