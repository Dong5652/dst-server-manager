import { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { Activity, Users, Cpu, Clock, Gauge } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { clusters, monitoring } from '@client/src/api';
import type { Cluster, MonitoringOverview, MonitoringStat } from '@shared/api.interface';

function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const parts: string[] = [];
  if (days > 0) parts.push(`${days}天`);
  if (hours > 0) parts.push(`${hours}小时`);
  parts.push(`${mins}分钟`);
  return parts.join('');
}

interface StatCard {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}

export default function MonitoringPage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedClusterId, setSelectedClusterId] = useState<string>('');
  const [overview, setOverview] = useState<MonitoringOverview | null>(null);
  const [historyData, setHistoryData] = useState<MonitoringStat[]>([]);
  const [loadingClusters, setLoadingClusters] = useState<boolean>(true);
  const [loadingData, setLoadingData] = useState<boolean>(false);
  const [timeRange, setTimeRange] = useState<24 | 168>(24);

  useEffect(() => {
    const load = async () => {
      try {
        setLoadingClusters(true);
        const list: Cluster[] = await clusters.list();
        setClusterList(list);
        if (list.length > 0) {
          setSelectedClusterId(list[0].id);
        }
      } catch (err: unknown) {
        logger.error('Failed to load clusters', err as Error);
      } finally {
        setLoadingClusters(false);
      }
    };
    void load();
  }, []);

  useEffect(() => {
    if (!selectedClusterId) return;
    const load = async () => {
      try {
        setLoadingData(true);
        const [ov, hist] = await Promise.all([
          monitoring.overview(selectedClusterId),
          monitoring.history({ clusterId: selectedClusterId, hours: timeRange }),
        ]);
        setOverview(ov);
        setHistoryData(hist);
      } catch (err: unknown) {
        logger.error('Failed to load monitoring data', err as Error);
      } finally {
        setLoadingData(false);
      }
    };
    void load();
  }, [selectedClusterId, timeRange]);

  const onlineOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    legend: { type: 'scroll', bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      data: historyData.map((s: MonitoringStat) =>
        new Date(s.createdAt).toLocaleTimeString('zh-CN', { hour12: false }),
      ),
      boundaryGap: false,
    },
    yAxis: { type: 'value', name: '人数' },
    series: [
      {
        name: '在线人数',
        type: 'line',
        smooth: true,
        data: historyData.map((s: MonitoringStat) => s.onlineCount),
        color: '#8b5cf6',
        areaStyle: { opacity: 0.1 },
      },
    ],
  };

  const memoryOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    legend: { type: 'scroll', bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      data: historyData.map((s: MonitoringStat) =>
        new Date(s.createdAt).toLocaleTimeString('zh-CN', { hour12: false }),
      ),
      boundaryGap: false,
    },
    yAxis: { type: 'value', name: 'MB' },
    series: [
      {
        name: '内存占用',
        type: 'line',
        smooth: true,
        data: historyData.map((s: MonitoringStat) => s.memoryMb),
        color: '#3b82f6',
        areaStyle: { opacity: 0.25 },
      },
    ],
  };

  if (loadingClusters) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  const statCards: StatCard[] = [
    { label: '在线人数', value: overview?.onlineCount ?? 0, icon: Users, color: 'text-[#22c55e]' },
    { label: '内存占用', value: `${overview?.memoryMb ?? 0} MB`, icon: Gauge, color: 'text-[#3b82f6]' },
    { label: 'CPU 使用率', value: `${overview?.cpuPercent ?? 0}%`, icon: Cpu, color: 'text-[#f59e0b]' },
    { label: '运行时长', value: formatUptime(overview?.uptimeSeconds ?? 0), icon: Clock, color: 'text-[#8b5cf6]' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-semibold">监控概览</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-56">
            <Select value={selectedClusterId} onValueChange={setSelectedClusterId}>
              <SelectTrigger>
                <SelectValue placeholder="选择集群" />
              </SelectTrigger>
              <SelectContent>
                {clusterList.map((c: Cluster) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex bg-muted rounded-md p-1">
            <Button
              size="sm"
              variant={timeRange === 24 ? 'default' : 'ghost'}
              onClick={() => setTimeRange(24)}
              className="px-4"
            >
              24小时
            </Button>
            <Button
              size="sm"
              variant={timeRange === 168 ? 'default' : 'ghost'}
              onClick={() => setTimeRange(168)}
              className="px-4"
            >
              7天
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" data-ai-section-type="card-list">
        {statCards.map((card) => {
          const IconC = card.icon;
          return (
            <Card key={card.label}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-muted-foreground">{card.label}</div>
                    <div className="text-2xl font-semibold mt-1">
                      {loadingData ? '...' : card.value}
                    </div>
                  </div>
                  <div className={`p-3 rounded-lg bg-muted ${card.color}`}>
                    <IconC className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">在线人数趋势</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingData ? (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              加载中...
            </div>
          ) : (
            <ReactECharts option={onlineOption} theme="ud" className="h-[300px] w-full" />
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">内存占用趋势</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingData ? (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              加载中...
            </div>
          ) : (
            <ReactECharts option={memoryOption} theme="ud" className="h-[300px] w-full" />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
