import React, { useEffect, useRef, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { ScrollText, RefreshCw, Search } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Switch } from '@client/src/components/ui/switch';
import { Label } from '@client/src/components/ui/label';
import { clusters, logs } from '@client/src/api';
import type { Cluster, ServerLog } from '@shared/api.interface';

type ServerTypeFilter = 'all' | 'master' | 'caves';
type LogLevelFilter = 'all' | 'info' | 'warn' | 'error';

const levelColorMap: Record<string, string> = {
  info: 'text-[#22c55e]',
  warn: 'text-[#f59e0b]',
  error: 'text-[#ef4444]',
  debug: 'text-[#8b5cf6]',
};

export default function LogsPage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedClusterId, setSelectedClusterId] = useState<string>('');
  const [serverType, setServerType] = useState<ServerTypeFilter>('all');
  const [logLevel, setLogLevel] = useState<LogLevelFilter>('all');
  const [keyword, setKeyword] = useState<string>('');
  const [logList, setLogList] = useState<ServerLog[]>([]);
  const [loadingClusters, setLoadingClusters] = useState<boolean>(true);
  const [loadingLogs, setLoadingLogs] = useState<boolean>(false);
  const [autoRefresh, setAutoRefresh] = useState<boolean>(false);
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadClusters = async () => {
      try {
        setLoadingClusters(true);
        const list: Cluster[] = await clusters.list();
        setClusterList(list);
        if (list.length > 0 && !selectedClusterId) {
          setSelectedClusterId(list[0].id);
        }
      } catch (err: unknown) {
        logger.error('Failed to load clusters', err as Error);
      } finally {
        setLoadingClusters(false);
      }
    };
    void loadClusters();
  }, []);

  const fetchLogs = async () => {
    if (!selectedClusterId) return;
    try {
      setLoadingLogs(true);
      const items: ServerLog[] = await logs.list({
        clusterId: selectedClusterId,
        serverType: serverType === 'all' ? undefined : serverType,
        logLevel: logLevel === 'all' ? undefined : logLevel,
        keyword: keyword || undefined,
        limit: 100,
      });
      setLogList(items);
    } catch (err: unknown) {
      logger.error('Failed to load logs', err as Error);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    if (!selectedClusterId) return;
    void fetchLogs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClusterId, serverType, logLevel, keyword]);

  useEffect(() => {
    if (!autoRefresh || !selectedClusterId) return;
    const timer = setInterval(() => {
      void fetchLogs();
    }, 5000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRefresh, selectedClusterId, serverType, logLevel, keyword]);

  useEffect(() => {
    if (autoScroll) {
      logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logList, autoScroll]);

  const formatTime = (iso: string) =>
    new Date(iso).toLocaleString('zh-CN', { hour12: false });

  if (loadingClusters) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ScrollText className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-semibold">服务器日志</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch id="auto-refresh" checked={autoRefresh} onCheckedChange={setAutoRefresh} />
            <Label htmlFor="auto-refresh" className="text-sm">自动刷新</Label>
          </div>
          <div className="flex items-center gap-2">
            <Switch id="auto-scroll" checked={autoScroll} onCheckedChange={setAutoScroll} />
            <Label htmlFor="auto-scroll" className="text-sm">自动滚动</Label>
          </div>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="w-56">
              <Select value={selectedClusterId} onValueChange={setSelectedClusterId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择集群" />
                </SelectTrigger>
                <SelectContent>
                  {clusterList.map((c: Cluster) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-36">
              <Select value={serverType} onValueChange={(v: string) => setServerType(v as ServerTypeFilter)}>
                <SelectTrigger>
                  <SelectValue placeholder="服务器类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="master">Master</SelectItem>
                  <SelectItem value="caves">Caves</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-32">
              <Select value={logLevel} onValueChange={(v: string) => setLogLevel(v as LogLevelFilter)}>
                <SelectTrigger>
                  <SelectValue placeholder="日志级别" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warn">Warn</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="关键词搜索"
                value={keyword}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setKeyword(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline" size="sm" onClick={fetchLogs}>
              <RefreshCw className="w-4 h-4 mr-2" />
              刷新
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            日志列表
            <span className="ml-2 text-sm font-normal text-muted-foreground">
              共 {logList.length} 条
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-background rounded-lg p-4 font-mono text-xs h-[500px] overflow-y-auto">
            {loadingLogs && logList.length === 0 ? (
              <div className="text-muted-foreground">加载中...</div>
            ) : logList.length === 0 ? (
              <div className="text-muted-foreground">暂无日志</div>
            ) : (
              <div className="space-y-1">
                {logList.map((log: ServerLog) => (
                  <div key={log.id} className="flex gap-3 leading-relaxed">
                    <span className="text-muted-foreground shrink-0">
                      [{formatTime(log.createdAt)}]
                    </span>
                    <span
                      className={`shrink-0 uppercase font-semibold w-14 ${
                        levelColorMap[log.logLevel] || 'text-foreground'
                      }`}
                    >
                      {log.logLevel}
                    </span>
                    <span className="text-primary shrink-0 w-20">
                      {log.serverType}
                    </span>
                    {log.source && (
                      <span className="text-[#60a5fa] shrink-0 w-24">
                        [{log.source}]
                      </span>
                    )}
                    <span className="text-foreground break-words flex-1">
                      {log.message}
                    </span>
                  </div>
                ))}
                <div ref={logEndRef} />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
