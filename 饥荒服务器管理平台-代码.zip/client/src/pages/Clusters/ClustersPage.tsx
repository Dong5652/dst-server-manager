import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Plus, Server } from 'lucide-react';
import { clusters } from '@client/src/api';
import type { Cluster } from '@shared/api.interface';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@client/src/components/ui/dialog';
import ClusterCard from './ClusterCard';

interface NewClusterForm {
  name: string;
  description: string;
  gameMode: 'survival' | 'endless' | 'wilderness';
  maxPlayers: number;
  hasCaves: boolean;
  clusterToken: string;
}

const DEFAULT_FORM: NewClusterForm = {
  name: '',
  description: '',
  gameMode: 'survival',
  maxPlayers: 6,
  hasCaves: true,
  clusterToken: '',
};

export default function ClustersPage() {
  const [items, setItems] = useState<Cluster[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [form, setForm] = useState<NewClusterForm>(DEFAULT_FORM);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [busyIds, setBusyIds] = useState<Set<string>>(new Set());

  const loadClusters = useCallback(async () => {
    try {
      setLoading(true);
      const data: Cluster[] = await clusters.list();
      setItems(data);
    } catch (error: unknown) {
      logger.error('获取集群列表失败', error);
      toast.error('获取集群列表失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadClusters();
  }, [loadClusters]);

  const setBusy = (id: string, busy: boolean) => {
    setBusyIds((prev: Set<string>) => {
      const next: Set<string> = new Set(prev);
      if (busy) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const handleStart = async (id: string) => {
    setBusy(id, true);
    try {
      await clusters.start(id);
      toast.success('已发送启动指令');
      await loadClusters();
    } catch (error: unknown) {
      logger.error('启动集群失败', error);
      toast.error('启动集群失败');
    } finally {
      setBusy(id, false);
    }
  };

  const handleRestart = async (id: string) => {
    setBusy(id, true);
    try {
      await clusters.restart(id);
      toast.success('已发送重启指令');
      await loadClusters();
    } catch (error: unknown) {
      logger.error('重启集群失败', error);
      toast.error('重启集群失败');
    } finally {
      setBusy(id, false);
    }
  };

  const handleStop = async (id: string) => {
    setBusy(id, true);
    try {
      await clusters.stop(id);
      toast.success('已发送停止指令');
      await loadClusters();
    } catch (error: unknown) {
      logger.error('停止集群失败', error);
      toast.error('停止集群失败');
    } finally {
      setBusy(id, false);
    }
  };

  const handleDelete = async (id: string) => {
    setBusy(id, true);
    try {
      await clusters.remove(id);
      toast.success('集群已删除');
      await loadClusters();
    } catch (error: unknown) {
      logger.error('删除集群失败', error);
      toast.error('删除集群失败');
    } finally {
      setBusy(id, false);
    }
  };

  const handleSubmitCreate = async () => {
    if (!form.name.trim()) {
      toast.error('请输入集群名称');
      return;
    }
    try {
      setSubmitting(true);
      await clusters.create({
        name: form.name.trim(),
        description: form.description.trim() || undefined,
        gameMode: form.gameMode,
        maxPlayers: Number(form.maxPlayers),
        hasCaves: form.hasCaves,
        clusterToken: form.clusterToken.trim() || undefined,
      });
      toast.success('集群创建成功');
      setDialogOpen(false);
      setForm(DEFAULT_FORM);
      await loadClusters();
    } catch (error: unknown) {
      logger.error('创建集群失败', error);
      toast.error('创建集群失败');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-ai-section-type="card-list">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">服务器集群</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4" />
              新建集群
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>新建集群</DialogTitle>
              <DialogDescription>
                创建一个新的饥荒联机版服务器集群
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="c-name">集群名称 *</Label>
                <Input
                  id="c-name"
                  value={form.name}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, name: e.target.value }))
                  }
                  placeholder="例如：我的生存服"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="c-desc">描述</Label>
                <Input
                  id="c-desc"
                  value={form.description}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, description: e.target.value }))
                  }
                  placeholder="可选"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>游戏模式</Label>
                  <Select
                    value={form.gameMode}
                    onValueChange={(val: string) =>
                      setForm((f) => ({
                        ...f,
                        gameMode: val as 'survival' | 'endless' | 'wilderness',
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="survival">生存</SelectItem>
                      <SelectItem value="endless">无尽</SelectItem>
                      <SelectItem value="wilderness">荒野</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="c-max">最大玩家数</Label>
                  <Input
                    id="c-max"
                    type="number"
                    min={1}
                    max={64}
                    value={form.maxPlayers}
                    onChange={(e) =>
                      setForm((f) => ({
                        ...f,
                        maxPlayers: Number(e.target.value),
                      }))
                    }
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">开启洞穴</div>
                  <div className="text-xs text-muted-foreground">
                    同时启动地面与洞穴服务器
                  </div>
                </div>
                <Switch
                  checked={form.hasCaves}
                  onCheckedChange={(v) =>
                    setForm((f) => ({ ...f, hasCaves: v }))
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="c-token">集群令牌</Label>
                <Input
                  id="c-token"
                  value={form.clusterToken}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, clusterToken: e.target.value }))
                  }
                  placeholder="可选，用于服务器验证"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setDialogOpen(false)}
                disabled={submitting}
              >
                取消
              </Button>
              <Button onClick={handleSubmitCreate} disabled={submitting}>
                确认创建
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {items.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Server className="h-10 w-10 mb-3 opacity-40" />
            <div>暂无集群，点击右上角新建</div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {items.map((cluster: Cluster) => (
            <ClusterCard
              key={cluster.id}
              cluster={cluster}
              busy={busyIds.has(cluster.id)}
              onStart={handleStart}
              onRestart={handleRestart}
              onStop={handleStop}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}
