import { useState } from 'react';
import {
  Play,
  Square,
  RotateCw,
  Settings,
  Trash2,
  Users,
  Mountain,
} from 'lucide-react';
import type { Cluster } from '@shared/api.interface';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';

const STATUS_LABEL: Record<string, string> = {
  running: '运行中',
  stopped: '已停止',
  starting: '启动中',
  stopping: '停止中',
  error: '错误',
};

const GAME_MODE_LABEL: Record<string, string> = {
  survival: '生存',
  endless: '无尽',
  wilderness: '荒野',
};

function statusBadgeClass(status: string): string {
  switch (status) {
    case 'running':
      return 'bg-success/20 text-success border-success/30';
    case 'starting':
    case 'stopping':
      return 'bg-warning/20 text-warning border-warning/30';
    case 'error':
      return 'bg-destructive/20 text-destructive border-destructive/30';
    default:
      return 'bg-muted text-muted-foreground border-border';
  }
}

interface ClusterCardProps {
  cluster: Cluster;
  busy: boolean;
  onStart: (id: string) => void;
  onRestart: (id: string) => void;
  onStop: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function ClusterCard({
  cluster,
  busy,
  onStart,
  onRestart,
  onStop,
  onDelete,
}: ClusterCardProps) {
  const [confirm, setConfirm] = useState<{
    action: 'stop' | 'delete' | null;
    open: boolean;
  }>({ action: null, open: false });
  const isRunning = cluster.status === 'running';
  const isStopped = cluster.status === 'stopped';
  const servers = cluster.servers ?? [];

  const handleConfirm = () => {
    if (confirm.action === 'stop') {
      onStop(cluster.id);
    } else if (confirm.action === 'delete') {
      onDelete(cluster.id);
    }
    setConfirm({ action: null, open: false });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-xl">{cluster.name}</CardTitle>
          <Badge
            variant="outline"
            className={statusBadgeClass(cluster.status)}
          >
            {STATUS_LABEL[cluster.status] ?? cluster.status}
          </Badge>
        </div>
        {cluster.description && (
          <div className="text-sm text-muted-foreground">
            {cluster.description}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Mountain className="h-4 w-4" />
            {GAME_MODE_LABEL[cluster.gameMode] ?? cluster.gameMode}
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Users className="h-4 w-4" />
            最多 {cluster.maxPlayers} 人
          </div>
          <Badge
            variant="outline"
            className={
              cluster.hasCaves
                ? 'bg-primary/10 text-primary border-primary/30'
                : 'bg-muted text-muted-foreground border-border'
            }
          >
            {cluster.hasCaves ? '已开启洞穴' : '无洞穴'}
          </Badge>
        </div>

        <div className="space-y-2">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            服务器实例
          </div>
          <div className="space-y-2">
            {servers.map((srv) => (
              <div
                key={srv.id}
                className="flex items-center justify-between rounded-md border border-border bg-muted/30 px-3 py-2 text-sm"
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium capitalize">
                    {srv.serverType}
                  </span>
                  <span className="text-muted-foreground">
                    端口 {srv.port}
                  </span>
                </div>
                <Badge
                  variant="outline"
                  className={statusBadgeClass(srv.status)}
                >
                  {STATUS_LABEL[srv.status] ?? srv.status}
                </Badge>
              </div>
            ))}
            {servers.length === 0 && (
              <div className="text-sm text-muted-foreground">暂无实例</div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-1">
          {isStopped && (
            <Button
              size="sm"
              variant="secondary"
              disabled={busy}
              onClick={() => onStart(cluster.id)}
            >
              <Play className="h-4 w-4" />
              启动
            </Button>
          )}
          {isRunning && (
            <AlertDialog
              open={confirm.open && confirm.action === 'stop'}
              onOpenChange={(open) =>
                setConfirm({ action: open ? 'stop' : null, open })
              }
            >
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="secondary" disabled={busy}>
                  <Square className="h-4 w-4" />
                  停止
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>确认停止集群？</AlertDialogTitle>
                  <AlertDialogDescription>
                    确定要停止集群「{cluster.name}」吗？
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>取消</AlertDialogCancel>
                  <AlertDialogAction onClick={handleConfirm}>
                    确认停止
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          {(isRunning || isStopped) && (
            <Button
              size="sm"
              variant="outline"
              disabled={busy}
              onClick={() => onRestart(cluster.id)}
            >
              <RotateCw className="h-4 w-4" />
              重启
            </Button>
          )}
          <Button size="sm" variant="outline" disabled={busy}>
            <Settings className="h-4 w-4" />
            配置
          </Button>
          <AlertDialog
            open={confirm.open && confirm.action === 'delete'}
            onOpenChange={(open) =>
              setConfirm({ action: open ? 'delete' : null, open })
            }
          >
            <AlertDialogTrigger asChild>
              <Button size="sm" variant="destructive" disabled={busy}>
                <Trash2 className="h-4 w-4" />
                删除
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>确认删除集群？</AlertDialogTitle>
                <AlertDialogDescription>
                  删除后世界存档与配置将被清除，不可撤销。
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>取消</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive hover:bg-destructive/90"
                  onClick={handleConfirm}
                >
                  确认删除
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
