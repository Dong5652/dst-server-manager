import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import {
  Plus,
  ArrowUp,
  ArrowDown,
  Trash2,
  Settings,
  Puzzle,
} from 'lucide-react';
import { clusters, mods } from '@client/src/api';
import type { Cluster, Mod } from '@shared/api.interface';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Badge } from '@client/src/components/ui/badge';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';

interface AddModForm {
  workshopId: string;
  modName: string;
  description: string;
  author: string;
}

const DEFAULT_ADD_FORM: AddModForm = {
  workshopId: '',
  modName: '',
  description: '',
  author: '',
};

export default function ModsPage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [modsList, setModsList] = useState<Mod[]>([]);
  const [listLoading, setListLoading] = useState<boolean>(false);
  const [addOpen, setAddOpen] = useState<boolean>(false);
  const [addForm, setAddForm] = useState<AddModForm>(DEFAULT_ADD_FORM);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [configMod, setConfigMod] = useState<Mod | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    open: boolean;
    id: string;
    name: string;
  }>({ open: false, id: '', name: '' });
  const [busyIds, setBusyIds] = useState<Set<string>>(new Set());

  const loadClusters = useCallback(async () => {
    try {
      setLoading(true);
      const list: Cluster[] = await clusters.list();
      setClusterList(list);
      if (list.length > 0) {
        setSelectedId(list[0].id);
      }
    } catch (error: unknown) {
      logger.error('获取集群列表失败', error);
      toast.error('获取集群列表失败');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadMods = useCallback(async (clusterId: string) => {
    if (!clusterId) return;
    try {
      setListLoading(true);
      const list: Mod[] = await mods.list(clusterId);
      setModsList(list.sort((a: Mod, b: Mod) => a.priority - b.priority));
    } catch (error: unknown) {
      logger.error('获取 Mod 列表失败', error);
      toast.error('获取 Mod 列表失败');
    } finally {
      setListLoading(false);
    }
  }, []);

  useEffect(() => {
    loadClusters();
  }, [loadClusters]);

  useEffect(() => {
    if (selectedId) {
      loadMods(selectedId);
    }
  }, [selectedId, loadMods]);

  const setBusy = (id: string, busy: boolean) => {
    setBusyIds((prev: Set<string>) => {
      const next: Set<string> = new Set(prev);
      if (busy) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const handleAdd = async () => {
    if (!addForm.workshopId.trim()) {
      toast.error('请输入创意工坊 ID');
      return;
    }
    if (!addForm.modName.trim()) {
      toast.error('请输入 Mod 名称');
      return;
    }
    if (!selectedId) return;
    try {
      setSubmitting(true);
      await mods.add({
        clusterId: selectedId,
        workshopId: addForm.workshopId.trim(),
        modName: addForm.modName.trim(),
        description: addForm.description.trim() || undefined,
        author: addForm.author.trim() || undefined,
      });
      toast.success('Mod 添加成功');
      setAddOpen(false);
      setAddForm(DEFAULT_ADD_FORM);
      await loadMods(selectedId);
    } catch (error: unknown) {
      logger.error('添加 Mod 失败', error);
      toast.error('添加 Mod 失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggle = async (mod: Mod) => {
    setBusy(mod.id, true);
    try {
      await mods.toggle(mod.id);
      await loadMods(selectedId);
      toast.success(mod.enabled ? 'Mod 已禁用' : 'Mod 已启用');
    } catch (error: unknown) {
      logger.error('切换 Mod 状态失败', error);
      toast.error('切换失败');
    } finally {
      setBusy(mod.id, false);
    }
  };

  const handleMove = async (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === modsList.length - 1) return;
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const newList: Mod[] = [...modsList];
    const [removed] = newList.splice(index, 1);
    newList.splice(targetIndex, 0, removed);
    setModsList(newList);
    try {
      await mods.reorder(
        selectedId,
        newList.map((m: Mod) => m.id),
      );
      toast.success('排序已更新');
    } catch (error: unknown) {
      logger.error('Mod 重排序失败', error);
      toast.error('排序失败');
      await loadMods(selectedId);
    }
  };

  const handleDelete = async () => {
    const { id } = deleteConfirm;
    setBusy(id, true);
    try {
      await mods.remove(id);
      toast.success('Mod 已删除');
      setDeleteConfirm({ open: false, id: '', name: '' });
      await loadMods(selectedId);
    } catch (error: unknown) {
      logger.error('删除 Mod 失败', error);
      toast.error('删除失败');
    } finally {
      setBusy(id, false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="text-2xl font-semibold">Mod 管理</h1>
          <div className="w-56">
            <Select value={selectedId} onValueChange={setSelectedId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择集群" />
              </SelectTrigger>
              <SelectContent>
                {clusterList.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button disabled={!selectedId}>
              <Plus className="h-4 w-4" />
              添加 Mod
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>添加 Mod</DialogTitle>
              <DialogDescription>
                通过创意工坊 ID 添加新的 Mod
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="m-ws">创意工坊 ID *</Label>
                <Input
                  id="m-ws"
                  value={addForm.workshopId}
                  onChange={(e) =>
                    setAddForm((f) => ({ ...f, workshopId: e.target.value }))
                  }
                  placeholder="例如：123456789"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="m-name">Mod 名称 *</Label>
                <Input
                  id="m-name"
                  value={addForm.modName}
                  onChange={(e) =>
                    setAddForm((f) => ({ ...f, modName: e.target.value }))
                  }
                  placeholder="Mod 显示名称"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="m-author">作者</Label>
                <Input
                  id="m-author"
                  value={addForm.author}
                  onChange={(e) =>
                    setAddForm((f) => ({ ...f, author: e.target.value }))
                  }
                  placeholder="可选"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="m-desc">描述</Label>
                <Input
                  id="m-desc"
                  value={addForm.description}
                  onChange={(e) =>
                    setAddForm((f) => ({ ...f, description: e.target.value }))
                  }
                  placeholder="可选"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setAddOpen(false)}
                disabled={submitting}
              >
                取消
              </Button>
              <Button onClick={handleAdd} disabled={submitting}>
                添加
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          {listLoading ? (
            <div className="py-12 text-center text-muted-foreground">
              加载中...
            </div>
          ) : modsList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Puzzle className="h-10 w-10 mb-3 opacity-40" />
              <div>暂无 Mod，点击右上角添加</div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">优先级</TableHead>
                  <TableHead>Mod 名称</TableHead>
                  <TableHead>创意工坊 ID</TableHead>
                  <TableHead>作者</TableHead>
                  <TableHead className="w-24">状态</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {modsList.map((mod: Mod, index: number) => (
                  <TableRow key={mod.id}>
                    <TableCell className="font-mono text-muted-foreground">
                      {index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{mod.modName}</div>
                      {mod.description && (
                        <div className="text-xs text-muted-foreground line-clamp-1">
                          {mod.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {mod.workshopId}
                    </TableCell>
                    <TableCell>{mod.author ?? '-'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={mod.enabled}
                          disabled={busyIds.has(mod.id)}
                          onCheckedChange={() => handleToggle(mod)}
                        />
                        <Badge
                          variant="outline"
                          className={
                            mod.enabled
                              ? 'bg-success/20 text-success border-success/30'
                              : 'bg-muted text-muted-foreground border-border'
                          }
                        >
                          {mod.enabled ? '启用' : '禁用'}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setConfigMod(mod)}
                          title="配置"
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={index === 0}
                          onClick={() => handleMove(index, 'up')}
                          title="上移"
                        >
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={index === modsList.length - 1}
                          onClick={() => handleMove(index, 'down')}
                          title="下移"
                        >
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                        <AlertDialog
                          open={
                            deleteConfirm.open && deleteConfirm.id === mod.id
                          }
                          onOpenChange={(open) =>
                            setDeleteConfirm({
                              open,
                              id: mod.id,
                              name: mod.modName,
                            })
                          }
                        >
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                确认删除 Mod？
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                确定要删除 Mod「{mod.modName}」吗？
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>取消</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive hover:bg-destructive/90"
                                onClick={handleDelete}
                              >
                                确认删除
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!configMod} onOpenChange={(o) => !o && setConfigMod(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Mod 配置</DialogTitle>
            <DialogDescription>
              {configMod?.modName} — 配置项
            </DialogDescription>
          </DialogHeader>
          <div className="py-2">
            {configMod &&
            configMod.modConfig.options &&
            configMod.modConfig.options.length > 0 ? (
              <div className="space-y-2">
                {configMod.modConfig.options.map(
                  (opt: { name: string; value: string | number | boolean }, i: number) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-md border border-border bg-muted/20 px-3 py-2 text-sm"
                    >
                      <span className="text-muted-foreground">{opt.name}</span>
                      <span className="font-mono">{String(opt.value)}</span>
                    </div>
                  ),
                )}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground py-4 text-center">
                该 Mod 暂无可配置项
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfigMod(null)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
