import { Users } from 'lucide-react';
import { LogOut } from 'lucide-react';
import type { Player } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import { useState } from 'react';

function formatDuration(seconds: number): string {
  const h: number = Math.floor(seconds / 3600);
  const m: number = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h} 小时 ${m} 分`;
  return `${m} 分钟`;
}

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '-';
  const d: Date = new Date(dateStr);
  return d.toLocaleString('zh-CN');
}

interface OnlinePlayersTabProps {
  list: Player[];
  loading: boolean;
  onKick: (id: string) => void;
}

export default function OnlinePlayersTab({
  list,
  loading,
  onKick,
}: OnlinePlayersTabProps) {
  const [kickConfirm, setKickConfirm] = useState<{
    open: boolean;
    id: string;
    name: string;
  }>({ open: false, id: '', name: '' });

  const handleConfirm = () => {
    onKick(kickConfirm.id);
    setKickConfirm({ open: false, id: '', name: '' });
  };

  if (loading) {
    return (
      <div className="py-12 text-center text-muted-foreground">加载中...</div>
    );
  }

  if (list.length === 0) {
    return (
      <div className="py-16 text-center text-muted-foreground">
        <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
        当前没有在线玩家
      </div>
    );
  }

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>玩家名</TableHead>
            <TableHead>Klei ID</TableHead>
            <TableHead>使用角色</TableHead>
            <TableHead>加入时间</TableHead>
            <TableHead>游戏时长</TableHead>
            <TableHead className="text-right">操作</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {list.map((p: Player) => (
            <TableRow key={p.id}>
              <TableCell className="font-medium">{p.playerName}</TableCell>
              <TableCell className="font-mono text-xs text-muted-foreground">
                {p.kleiId}
              </TableCell>
              <TableCell>{p.characterUsed ?? '-'}</TableCell>
              <TableCell>{formatTime(p.lastJoinAt)}</TableCell>
              <TableCell>{formatDuration(p.playtimeSeconds)}</TableCell>
              <TableCell className="text-right">
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() =>
                    setKickConfirm({
                      open: true,
                      id: p.id,
                      name: p.playerName,
                    })
                  }
                >
                  <LogOut className="h-4 w-4" />
                  踢出
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <AlertDialog
        open={kickConfirm.open}
        onOpenChange={(open) =>
          setKickConfirm({ ...kickConfirm, open })
        }
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认踢出玩家？</AlertDialogTitle>
            <AlertDialogDescription>
              确定要踢出玩家「{kickConfirm.name}」吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={handleConfirm}
            >
              确认踢出
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
