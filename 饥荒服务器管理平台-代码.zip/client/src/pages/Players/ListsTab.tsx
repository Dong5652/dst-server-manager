import { useState } from 'react';
import { UserX } from 'lucide-react';
import type { PlayerListEntry } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@client/src/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';

type ListType = 'admin' | 'whitelist' | 'ban';

const LIST_LABEL: Record<ListType, string> = {
  admin: '管理员',
  whitelist: '白名单',
  ban: '封禁',
};

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '-';
  const d: Date = new Date(dateStr);
  return d.toLocaleString('zh-CN');
}

interface ListsTabProps {
  listType: ListType;
  setListType: (t: ListType) => void;
  entries: PlayerListEntry[];
  loading: boolean;
  onAdd: (listType: ListType, data: {
    kleiId: string;
    playerName: string;
    reason: string;
  }) => void;
  onRemove: (id: string) => void;
  submitting: boolean;
}

export default function ListsTab({
  listType,
  setListType,
  entries,
  loading,
  onAdd,
  onRemove,
  submitting,
}: ListsTabProps) {
  const [addOpen, setAddOpen] = useState<boolean>(false);
  const [removeId, setRemoveId] = useState<string>('');
  const [removeName, setRemoveName] = useState<string>('');
  const [form, setForm] = useState({
    kleiId: '',
    playerName: '',
    reason: '',
  });

  const handleSubmitAdd = () => {
    onAdd(listType, form);
    setAddOpen(false);
    setForm({ kleiId: '', playerName: '', reason: '' });
  };

  const handleConfirmRemove = () => {
    onRemove(removeId);
    setRemoveId('');
    setRemoveName('');
  };

  return (
    <Tabs value={listType} onValueChange={(v: string) => setListType(v as ListType)} className="w-full">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <TabsList>
          <TabsTrigger value="admin">管理员</TabsTrigger>
          <TabsTrigger value="whitelist">白名单</TabsTrigger>
          <TabsTrigger value="ban">封禁</TabsTrigger>
        </TabsList>
        <Button size="sm" onClick={() => setAddOpen(true)}>
          <UserX className="h-4 w-4 mr-1" />
          添加到{LIST_LABEL[listType]}
        </Button>
      </div>

      {(['admin', 'whitelist', 'ban'] as ListType[]).map((type) => (
        <TabsContent key={type} value={type} className="pt-4">
          <ListTable
            entries={entries}
            loading={loading && listType === type}
            onRemove={(id, name) => {
              setRemoveId(id);
              setRemoveName(name);
            }}
          />
        </TabsContent>
      ))}

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>添加到{LIST_LABEL[listType]}</DialogTitle>
            <DialogDescription>
              通过 Klei ID 将玩家加入{LIST_LABEL[listType]}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="li-klei">Klei ID *</Label>
              <Input
                id="li-klei"
                value={form.kleiId}
                onChange={(e) =>
                  setForm((f) => ({ ...f, kleiId: e.target.value }))
                }
                placeholder="Klei 玩家唯一 ID"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="li-name">玩家名</Label>
              <Input
                id="li-name"
                value={form.playerName}
                onChange={(e) =>
                  setForm((f) => ({ ...f, playerName: e.target.value }))
                }
                placeholder="可选"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="li-reason">原因</Label>
              <Input
                id="li-reason"
                value={form.reason}
                onChange={(e) =>
                  setForm((f) => ({ ...f, reason: e.target.value }))
                }
                placeholder="可选"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAddOpen(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <Button onClick={handleSubmitAdd} disabled={submitting}>
              添加
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!removeId}
        onOpenChange={(open) => !open && setRemoveId('')}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认移除？</AlertDialogTitle>
            <AlertDialogDescription>
              确定要移除「{removeName}」吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={handleConfirmRemove}
            >
              确认移除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Tabs>
  );
}

interface ListTableProps {
  entries: PlayerListEntry[];
  loading: boolean;
  onRemove: (id: string, name: string) => void;
}

function ListTable({ entries, loading, onRemove }: ListTableProps) {
  if (loading) {
    return (
      <div className="py-12 text-center text-muted-foreground">加载中...</div>
    );
  }
  if (entries.length === 0) {
    return (
      <div className="py-12 text-center text-muted-foreground">暂无记录</div>
    );
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>玩家名</TableHead>
          <TableHead>Klei ID</TableHead>
          <TableHead>原因</TableHead>
          <TableHead>添加时间</TableHead>
          <TableHead className="text-right">操作</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {entries.map((entry: PlayerListEntry) => (
          <TableRow key={entry.id}>
            <TableCell className="font-medium">
              {entry.playerName ?? '-'}
            </TableCell>
            <TableCell className="font-mono text-xs text-muted-foreground">
              {entry.kleiId}
            </TableCell>
            <TableCell>{entry.reason ?? '-'}</TableCell>
            <TableCell>{formatTime(entry.addedAt)}</TableCell>
            <TableCell className="text-right">
              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  onRemove(entry.id, entry.playerName ?? entry.kleiId)
                }
              >
                移除
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
