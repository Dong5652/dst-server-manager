import { ShieldCheck, Ban } from 'lucide-react';
import type { Player } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';

type ListType = 'admin' | 'whitelist' | 'ban';

function formatDuration(seconds: number): string {
  const h: number = Math.floor(seconds / 3600);
  const m: number = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h} 小时 ${m} 分`;
  return `${m} 分钟`;
}

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '-';
  const d: Date = new Date(dateStr);
  return d.toLocaleString('zh-CN');
}

interface AllPlayersTabProps {
  list: Player[];
  loading: boolean;
  onAddToList: (listType: ListType, player: Player) => void;
}

export default function AllPlayersTab({
  list,
  loading,
  onAddToList,
}: AllPlayersTabProps) {
  if (loading) {
    return (
      <div className="py-12 text-center text-muted-foreground">加载中...</div>
    );
  }

  if (list.length === 0) {
    return (
      <div className="py-16 text-center text-muted-foreground">
        暂无玩家记录
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>玩家名</TableHead>
          <TableHead>Klei ID</TableHead>
          <TableHead>状态</TableHead>
          <TableHead>最后加入</TableHead>
          <TableHead>游戏时长</TableHead>
          <TableHead className="text-right">操作</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {list.map((p: Player) => (
          <TableRow key={p.id}>
            <TableCell className="font-medium">{p.playerName}</TableCell>
            <TableCell className="font-mono text-xs text-muted-foreground">
              {p.kleiId}
            </TableCell>
            <TableCell>
              <Badge
                variant="outline"
                className={
                  p.isOnline
                    ? 'bg-success/20 text-success border-success/30'
                    : 'bg-muted text-muted-foreground border-border'
                }
              >
                {p.isOnline ? '在线' : '离线'}
              </Badge>
            </TableCell>
            <TableCell>{formatTime(p.lastJoinAt)}</TableCell>
            <TableCell>{formatDuration(p.playtimeSeconds)}</TableCell>
            <TableCell className="text-right">
              <div className="flex items-center justify-end gap-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onAddToList('admin', p)}
                >
                  <ShieldCheck className="h-3.5 w-3.5 mr-1" />
                  管理员
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onAddToList('whitelist', p)}
                >
                  白名单
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => onAddToList('ban', p)}
                >
                  <Ban className="h-3.5 w-3.5 mr-1" />
                  封禁
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
