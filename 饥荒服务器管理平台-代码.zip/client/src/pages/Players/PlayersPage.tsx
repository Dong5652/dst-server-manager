import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Users, ShieldCheck } from 'lucide-react';
import { clusters, players } from '@client/src/api';
import type { Cluster, Player, PlayerListEntry } from '@shared/api.interface';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@client/src/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';

type ListType = 'admin' | 'whitelist' | 'ban';

const LIST_LABEL: Record<ListType, string> = {
  admin: '管理员',
  whitelist: '白名单',
  ban: '封禁',
};

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h} 小时 ${m} 分`;
  return `${m} 分钟`;
}

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleString('zh-CN');
}

export default function PlayersPage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [onlineList, setOnlineList] = useState<Player[]>([]);
  const [allList, setAllList] = useState<Player[]>([]);
  const [listLoading, setListLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('online');
  const [listTab, setListTab] = useState<ListType>('admin');
  const [listEntries, setListEntries] = useState<PlayerListEntry[]>([]);
  const [listTabLoading, setListTabLoading] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [kickConfirm, setKickConfirm] = useState<{
    open: boolean;
    id: string;
    name: string;
  }>({ open: false, id: '', name: '' });
  const [addDialogOpen, setAddDialogOpen] = useState<boolean>(false);
  const [addForm, setAddForm] = useState({
    kleiId: '',
    playerName: '',
    reason: '',
  });
  const [removeConfirm, setRemoveConfirm] = useState<{
    open: boolean;
    id: string;
    name: string;
  }>({ open: false, id: '', name: '' });

  const loadClusters = useCallback(async () => {
    try {
      setLoading(true);
      const res = await clusters.list();
      const list: Cluster[] = res as unknown as Cluster[];
      setClusterList(list);
      if (list.length > 0) {
        setSelectedId(list[0].id);
      }
    } catch (error: unknown) {
      logger.error('获取集群列表失败', error as Error);
      toast.error('获取集群列表失败');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadOnline = useCallback(async (clusterId: string) => {
    if (!clusterId) return;
    try {
      setListLoading(true);
      const list = await players.list({ clusterId, onlineOnly: true });
      setOnlineList(list);
    } catch (error: unknown) {
      logger.error('获取在线玩家失败', error as Error);
      toast.error('获取在线玩家失败');
    } finally {
      setListLoading(false);
    }
  }, []);

  const loadAll = useCallback(async (clusterId: string) => {
    if (!clusterId) return;
    try {
      setListLoading(true);
      const list = await players.list({ clusterId, onlineOnly: false });
      setAllList(list);
    } catch (error: unknown) {
      logger.error('获取玩家列表失败', error as Error);
      toast.error('获取玩家列表失败');
    } finally {
      setListLoading(false);
    }
  }, []);

  const loadListEntries = useCallback(
    async (clusterId: string, listType: ListType) => {
      if (!clusterId) return;
      try {
        setListTabLoading(true);
        const list = await players.getLists({ clusterId, listType });
        setListEntries(list);
      } catch (error: unknown) {
        logger.error('获取名单失败', error as Error);
        toast.error('获取名单失败');
      } finally {
        setListTabLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    loadClusters();
  }, [loadClusters]);

  useEffect(() => {
    if (!selectedId) return;
    if (activeTab === 'online') loadOnline(selectedId);
    else if (activeTab === 'all') loadAll(selectedId);
    else if (activeTab === 'lists') loadListEntries(selectedId, listTab);
  }, [selectedId, activeTab, listTab, loadOnline, loadAll, loadListEntries]);

  const handleKick = async () => {
    try {
      await players.kick(kickConfirm.id);
      toast.success('已踢出玩家');
      setKickConfirm({ open: false, id: '', name: '' });
      if (selectedId) await loadOnline(selectedId);
    } catch (error: unknown) {
      logger.error('踢出玩家失败', error as Error);
      toast.error('踢出失败');
    }
  };

  const handleAddToList = async (listType: ListType, player: Player) => {
    if (!selectedId) return;
    try {
      await players.addToList({
        clusterId: selectedId,
        listType,
        kleiId: player.kleiId,
        playerName: player.playerName,
      });
      toast.success('已添加到名单');
    } catch (error: unknown) {
      logger.error('添加到名单失败', error as Error);
      toast.error('添加失败');
    }
  };

  const handleAddByForm = async () => {
    if (!addForm.kleiId.trim()) {
      toast.error('请输入 Klei ID');
      return;
    }
    if (!selectedId) return;
    try {
      setSubmitting(true);
      await players.addToList({
        clusterId: selectedId,
        listType: listTab,
        kleiId: addForm.kleiId.trim(),
        playerName: addForm.playerName.trim() || undefined,
        reason: addForm.reason.trim() || undefined,
      });
      toast.success('添加成功');
      setAddDialogOpen(false);
      setAddForm({ kleiId: '', playerName: '', reason: '' });
      loadListEntries(selectedId, listTab);
    } catch (error: unknown) {
      logger.error('添加到名单失败', error as Error);
      toast.error('添加失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRemoveFromList = async () => {
    try {
      await players.removeFromList(removeConfirm.id);
      toast.success('已移除');
      setRemoveConfirm({ open: false, id: '', name: '' });
      if (selectedId) loadListEntries(selectedId, listTab);
    } catch (error: unknown) {
      logger.error('移除失败', error as Error);
      toast.error('移除失败');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 flex-wrap">
        <h1 className="text-2xl font-semibold">玩家管理</h1>
        <div className="w-56">
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="选择集群" />
            </SelectTrigger>
            <SelectContent>
              {clusterList.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="online">
                <Users className="h-4 w-4 mr-1.5" />
                在线玩家
              </TabsTrigger>
              <TabsTrigger value="all">
                <Users className="h-4 w-4 mr-1.5" />
                全部玩家
              </TabsTrigger>
              <TabsTrigger value="lists">
                <ShieldCheck className="h-4 w-4 mr-1.5" />
                名单管理
              </TabsTrigger>
            </TabsList>

            <TabsContent value="online" className="pt-4">
              {listLoading ? (
                <div className="py-12 text-center text-muted-foreground">加载中...</div>
              ) : onlineList.length === 0 ? (
                <div className="py-16 text-center text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  当前没有在线玩家
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>玩家名</TableHead>
                      <TableHead>Klei ID</TableHead>
                      <TableHead>使用角色</TableHead>
                      <TableHead>加入时间</TableHead>
                      <TableHead>游戏时长</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {onlineList.map((p: Player) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">{p.playerName}</TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {p.kleiId}
                        </TableCell>
                        <TableCell>{p.characterUsed ?? '-'}</TableCell>
                        <TableCell>{formatTime(p.lastJoinAt)}</TableCell>
                        <TableCell>{formatDuration(p.playtimeSeconds)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() =>
                              setKickConfirm({
                                open: true,
                                id: p.id,
                                name: p.playerName,
                              })
                            }
                          >
                            踢出
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>

            <TabsContent value="all" className="pt-4">
              {listLoading ? (
                <div className="py-12 text-center text-muted-foreground">加载中...</div>
              ) : allList.length === 0 ? (
                <div className="py-16 text-center text-muted-foreground">暂无玩家记录</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>玩家名</TableHead>
                      <TableHead>Klei ID</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>最后加入</TableHead>
                      <TableHead>游戏时长</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allList.map((p: Player) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">{p.playerName}</TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {p.kleiId}
                        </TableCell>
                        <TableCell>
                          <Badge variant={p.isOnline ? 'default' : 'secondary'}>
                            {p.isOnline ? '在线' : '离线'}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatTime(p.lastJoinAt)}</TableCell>
                        <TableCell>{formatDuration(p.playtimeSeconds)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAddToList('admin', p)}
                            >
                              管理员
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAddToList('whitelist', p)}
                            >
                              白名单
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleAddToList('ban', p)}
                            >
                              封禁
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>

            <TabsContent value="lists" className="pt-4">
              <div className="flex items-center justify-between mb-4">
                <Tabs value={listTab} onValueChange={(v: string) => setListTab(v as ListType)}>
                  <TabsList>
                    <TabsTrigger value="admin">管理员</TabsTrigger>
                    <TabsTrigger value="whitelist">白名单</TabsTrigger>
                    <TabsTrigger value="ban">封禁</TabsTrigger>
                  </TabsList>
                </Tabs>
                <Button size="sm" onClick={() => setAddDialogOpen(true)}>
                  添加到{LIST_LABEL[listTab]}
                </Button>
              </div>
              {listTabLoading ? (
                <div className="py-12 text-center text-muted-foreground">加载中...</div>
              ) : listEntries.length === 0 ? (
                <div className="py-16 text-center text-muted-foreground">暂无记录</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>玩家名</TableHead>
                      <TableHead>Klei ID</TableHead>
                      <TableHead>原因</TableHead>
                      <TableHead>添加时间</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {listEntries.map((entry: PlayerListEntry) => (
                      <TableRow key={entry.id}>
                        <TableCell className="font-medium">
                          {entry.playerName ?? '-'}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {entry.kleiId}
                        </TableCell>
                        <TableCell>{entry.reason ?? '-'}</TableCell>
                        <TableCell>{formatTime(entry.addedAt)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              setRemoveConfirm({
                                open: true,
                                id: entry.id,
                                name: entry.playerName ?? entry.kleiId,
                              })
                            }
                          >
                            移除
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <AlertDialog
        open={kickConfirm.open}
        onOpenChange={(open) => setKickConfirm({ ...kickConfirm, open })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认踢出玩家？</AlertDialogTitle>
            <AlertDialogDescription>
              确定要踢出玩家「{kickConfirm.name}」吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={handleKick}
            >
              确认踢出
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              添加到{LIST_LABEL[listTab]}
            </DialogTitle>
            <DialogDescription>
              输入玩家信息后点击确认添加
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="add-klei">Klei ID *</Label>
              <Input
                id="add-klei"
                value={addForm.kleiId}
                onChange={(e) => setAddForm({ ...addForm, kleiId: e.target.value })}
                placeholder="Klei 玩家唯一 ID"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-name">玩家名</Label>
              <Input
                id="add-name"
                value={addForm.playerName}
                onChange={(e) => setAddForm({ ...addForm, playerName: e.target.value })}
                placeholder="可选"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-reason">原因</Label>
              <Input
                id="add-reason"
                value={addForm.reason}
                onChange={(e) => setAddForm({ ...addForm, reason: e.target.value })}
                placeholder="可选"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleAddByForm} disabled={submitting}>
              {submitting ? '添加中...' : '确认添加'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={removeConfirm.open}
        onOpenChange={(open) => setRemoveConfirm({ ...removeConfirm, open })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认移除？</AlertDialogTitle>
            <AlertDialogDescription>
              确定要将「{removeConfirm.name}」从{LIST_LABEL[listTab]}中移除吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={handleRemoveFromList}
            >
              确认移除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
