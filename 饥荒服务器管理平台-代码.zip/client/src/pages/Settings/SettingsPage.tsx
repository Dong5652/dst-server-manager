import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Settings, Key, Download, Trash2, Save, Play } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { settings } from '@client/src/api';
import type { SystemSetting, BackupEntry } from '@shared/api.interface';

function getSettingValue(items: SystemSetting[], key: string, fallback: string = ''): string {
  const item = items.find((s: SystemSetting) => s.settingKey === key);
  return item?.settingValue ?? fallback;
}

export default function SettingsPage() {
  const [settingList, setSettingList] = useState<SystemSetting[]>([]);
  const [backups, setBackups] = useState<BackupEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [creatingBackup, setCreatingBackup] = useState<boolean>(false);

  // Steam config
  const [steamApiKey, setSteamApiKey] = useState<string>('');
  // Basic settings
  const [maxPlayers, setMaxPlayers] = useState<string>('');
  const [logLevel, setLogLevel] = useState<string>('info');
  const [serverPath, setServerPath] = useState<string>('');
  // Backup
  const [autoBackup, setAutoBackup] = useState<boolean>(false);
  const [backupInterval, setBackupInterval] = useState<string>('');
  const [backupRetention, setBackupRetention] = useState<string>('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [items, backupList] = await Promise.all([
        settings.list(),
        settings.getBackups(),
      ]);
      setSettingList(items);
      setBackups(backupList);
      // Populate form
      setSteamApiKey(getSettingValue(items, 'steam_api_key'));
      setMaxPlayers(getSettingValue(items, 'default_max_players', '6'));
      setLogLevel(getSettingValue(items, 'log_level', 'info'));
      setServerPath(getSettingValue(items, 'server_base_path'));
      setAutoBackup(getSettingValue(items, 'auto_backup', 'false') === 'true');
      setBackupInterval(getSettingValue(items, 'backup_interval_hours', '24'));
      setBackupRetention(getSettingValue(items, 'backup_retention_days', '30'));
    } catch (err: unknown) {
      logger.error('Failed to load settings', err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadData();
  }, []);

  const updateSetting = async (key: string, value: string | number | boolean) => {
    try {
      const updated: SystemSetting = await settings.update(key, value);
      setSettingList((prev) => {
        const exists = prev.some((s: SystemSetting) => s.settingKey === key);
        if (exists) {
          return prev.map((s: SystemSetting) =>
            s.settingKey === key ? updated : s,
          );
        }
        return [...prev, updated];
      });
    } catch (err: unknown) {
      logger.error(`Failed to update setting ${key}`, err as Error);
    }
  };

  const handleSaveSteam = async () => {
    setSaving(true);
    await updateSetting('steam_api_key', steamApiKey);
    setSaving(false);
  };

  const handleSaveBasic = async () => {
    setSaving(true);
    await Promise.all([
      updateSetting('default_max_players', Number(maxPlayers) || 6),
      updateSetting('log_level', logLevel),
      updateSetting('server_base_path', serverPath),
    ]);
    setSaving(false);
  };

  const handleAutoBackupToggle = async (checked: boolean) => {
    setAutoBackup(checked);
    await updateSetting('auto_backup', checked);
  };

  const handleSaveBackup = async () => {
    setSaving(true);
    await Promise.all([
      updateSetting('backup_interval_hours', Number(backupInterval) || 24),
      updateSetting('backup_retention_days', Number(backupRetention) || 30),
    ]);
    setSaving(false);
  };

  const handleCreateBackup = async () => {
    try {
      setCreatingBackup(true);
      await settings.createBackup();
      const list: BackupEntry[] = await settings.getBackups();
      setBackups(list);
    } catch (err: unknown) {
      logger.error('Failed to create backup', err as Error);
    } finally {
      setCreatingBackup(false);
    }
  };

  const handleDownload = (name: string) => {
    logger.info(`Downloading backup: ${name}`);
  };

  const handleDelete = (name: string) => {
    logger.info(`Deleting backup: ${name}`);
    setBackups((prev) => prev.filter((b: BackupEntry) => b.name !== name));
  };

  const formatSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatTime = (iso: string): string =>
    new Date(iso).toLocaleString('zh-CN', { hour12: false });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Settings className="w-6 h-6 text-primary" />
        <h1 className="text-xl font-semibold">系统设置</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Key className="w-4 h-4" />
            Steam 配置
          </CardTitle>
          <CardDescription>配置 Steam API 密钥用于服务器认证</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 max-w-md">
            <Label htmlFor="steam-api-key">Steam API 密钥</Label>
            <Input
              id="steam-api-key"
              type="password"
              value={steamApiKey}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSteamApiKey(e.target.value)
              }
              placeholder="输入 Steam API 密钥"
            />
            <p className="text-xs text-muted-foreground">
              密钥用于服务器令牌验证，可在 Steam 开发者网站获取
            </p>
          </div>
          <Button onClick={handleSaveSteam} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? '保存中...' : '保存'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">基础设置</CardTitle>
          <CardDescription>服务器默认参数和文件路径配置</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="max-players">默认最大人数</Label>
              <Input
                id="max-players"
                type="number"
                value={maxPlayers}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setMaxPlayers(e.target.value)
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="log-level">日志级别</Label>
              <Select value={logLevel} onValueChange={setLogLevel}>
                <SelectTrigger id="log-level">
                  <SelectValue placeholder="选择日志级别" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warn">Warn</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="debug">Debug</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="server-path">服务器文件基础路径</Label>
            <Input
              id="server-path"
              value={serverPath}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setServerPath(e.target.value)
              }
              placeholder="/home/dst/server"
            />
          </div>
          <Button onClick={handleSaveBasic} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? '保存中...' : '保存'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">备份管理</CardTitle>
          <CardDescription>配置自动备份策略和管理备份文件</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Switch
                id="auto-backup"
                checked={autoBackup}
                onCheckedChange={handleAutoBackupToggle}
              />
              <Label htmlFor="auto-backup">自动备份</Label>
            </div>
            <Button variant="secondary" onClick={handleCreateBackup} disabled={creatingBackup}>
              <Play className="w-4 h-4 mr-2" />
              {creatingBackup ? '备份中...' : '立即备份'}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="backup-interval">备份间隔（小时）</Label>
              <Input
                id="backup-interval"
                type="number"
                value={backupInterval}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setBackupInterval(e.target.value)
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="backup-retention">备份保留天数</Label>
              <Input
                id="backup-retention"
                type="number"
                value={backupRetention}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setBackupRetention(e.target.value)
                }
              />
            </div>
          </div>

          <Button onClick={handleSaveBackup} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? '保存中...' : '保存备份设置'}
          </Button>

          <div className="space-y-3">
            <div className="text-sm font-medium">备份列表</div>
            {backups.length === 0 ? (
              <div className="text-sm text-muted-foreground">暂无备份文件</div>
            ) : (
              <div className="space-y-2">
                {backups.map((b: BackupEntry) => (
                  <div
                    key={b.name}
                    className="flex items-center justify-between p-3 bg-muted rounded-md"
                  >
                    <div className="space-y-1">
                      <div className="text-sm font-medium">{b.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {formatSize(b.size)} · {formatTime(b.createdAt)}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownload(b.name)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive"
                        onClick={() => handleDelete(b.name)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
