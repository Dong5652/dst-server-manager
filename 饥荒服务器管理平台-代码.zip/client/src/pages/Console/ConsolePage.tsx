import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Terminal,
  Send,
  Save,
  RotateCcw,
  Sun,
  Snowflake,
  Zap,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { consoleApi, clusters } from '@client/src/api';
import type { Cluster, ConsoleCommand } from '@shared/api.interface';

const QUICK_COMMANDS = [
  { label: '公告', command: 'c_announce("公告内容")', icon: Sparkles },
  { label: '保存世界', command: 'c_save()', icon: Save },
  { label: '回滚', command: 'c_rollback(3)', icon: RotateCcw },
  { label: '切换白天', command: 'TheWorld:PushEvent("ms_forcewarday")', icon: Sun },
  { label: '切换冬天', command: 'TheWorld:PushEvent("ms_setseason", "winter")', icon: Snowflake },
  { label: '上帝模式', command: 'c_supergodmode(true)', icon: Zap },
  { label: '生成世界', command: 'c_regenerateworld()', icon: Sparkles },
];

export default function ConsolePage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedClusterId, setSelectedClusterId] = useState<string>('');
  const [commandText, setCommandText] = useState<string>('');
  const [history, setHistory] = useState<ConsoleCommand[]>([]);
  const [loadingClusters, setLoadingClusters] = useState<boolean>(true);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(false);
  const [sending, setSending] = useState<boolean>(false);

  useEffect(() => {
    const loadClusters = async () => {
      try {
        setLoadingClusters(true);
        const list: Cluster[] = await clusters.list();
        setClusterList(list);
        if (list.length > 0 && !selectedClusterId) {
          setSelectedClusterId(list[0].id);
        }
      } catch (err: unknown) {
        logger.error('Failed to load clusters', err as Error);
      } finally {
        setLoadingClusters(false);
      }
    };
    void loadClusters();
  }, []);

  useEffect(() => {
    if (!selectedClusterId) return;
    const loadHistory = async () => {
      try {
        setLoadingHistory(true);
        const items: ConsoleCommand[] = await consoleApi.history({
          clusterId: selectedClusterId,
          limit: 20,
        });
        setHistory(items);
      } catch (err: unknown) {
        logger.error('Failed to load command history', err as Error);
      } finally {
        setLoadingHistory(false);
      }
    };
    void loadHistory();
  }, [selectedClusterId]);

  const handleQuickClick = (cmd: string) => {
    setCommandText(cmd);
  };

  const handleSend = async () => {
    if (!selectedClusterId || !commandText.trim() || sending) return;
    try {
      setSending(true);
      const result: ConsoleCommand = await consoleApi.execute({
        clusterId: selectedClusterId,
        command: commandText.trim(),
      });
      setHistory((prev) => [result, ...prev]);
      setCommandText('');
    } catch (err: unknown) {
      logger.error('Failed to execute command', err as Error);
    } finally {
      setSending(false);
    }
  };

  const handleRefresh = async () => {
    if (!selectedClusterId) return;
    try {
      setLoadingHistory(true);
      const items: ConsoleCommand[] = await consoleApi.history({
        clusterId: selectedClusterId,
        limit: 20,
      });
      setHistory(items);
    } catch (err: unknown) {
      logger.error('Failed to refresh history', err as Error);
    } finally {
      setLoadingHistory(false);
    }
  };

  const formatTime = (iso: string) =>
    new Date(iso).toLocaleString('zh-CN', { hour12: false });

  if (loadingClusters) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Terminal className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-semibold">控制台</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-56">
            <Select value={selectedClusterId} onValueChange={setSelectedClusterId}>
              <SelectTrigger>
                <SelectValue placeholder="选择集群" />
              </SelectTrigger>
              <SelectContent>
                {clusterList.map((c: Cluster) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">快捷命令</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {QUICK_COMMANDS.map((cmd) => {
              const IconC = cmd.icon;
              return (
                <Button
                  key={cmd.label}
                  variant="secondary"
                  size="sm"
                  onClick={() => handleQuickClick(cmd.command)}
                >
                  <IconC className="w-4 h-4 mr-2" />
                  {cmd.label}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">命令输入</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            placeholder="输入控制台命令，例如：c_save()"
            value={commandText}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
              setCommandText(e.target.value)
            }
            className="font-mono text-sm min-h-[100px] resize-none"
          />
          <div className="flex justify-end">
            <Button onClick={handleSend} disabled={sending || !commandText.trim()}>
              <Send className="w-4 h-4 mr-2" />
              {sending ? '执行中...' : '发送'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">命令历史</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-background rounded-lg p-4 font-mono text-sm max-h-[400px] overflow-y-auto">
            {loadingHistory ? (
              <div className="text-muted-foreground">加载中...</div>
            ) : history.length === 0 ? (
              <div className="text-muted-foreground">暂无命令历史</div>
            ) : (
              <div className="space-y-4">
                {history.map((item: ConsoleCommand) => (
                  <div key={item.id} className="border-b border-border/50 pb-3 last:border-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-primary">$ {item.command}</span>
                      <span className="text-xs text-muted-foreground">
                        {formatTime(item.createdAt)}
                      </span>
                    </div>
                    <div className="text-muted-foreground whitespace-pre-wrap break-words">
                      {item.result || '(无输出)'}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
