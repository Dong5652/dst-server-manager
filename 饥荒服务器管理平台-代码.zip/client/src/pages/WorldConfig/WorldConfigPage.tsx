import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Globe, Save, Loader2 } from 'lucide-react';
import { clusters, worldConfig } from '@client/src/api';
import type { Cluster, WorldConfig as WorldConfigType } from '@shared/api.interface';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';

const WORLD_SIZE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: 'tiny', label: '极小 (Tiny)' },
  { value: 'small', label: '小 (Small)' },
  { value: 'default', label: '默认 (Default)' },
  { value: 'medium', label: '中 (Medium)' },
  { value: 'large', label: '大 (Large)' },
  { value: 'huge', label: '巨大 (Huge)' },
];

const GAME_MODE_LABEL: Record<string, string> = {
  survival: '生存',
  endless: '无尽',
  wilderness: '荒野',
};

type WorldSize = 'tiny' | 'small' | 'default' | 'medium' | 'large' | 'huge';

interface ConfigForm {
  worldSize: WorldSize;
  daySeasonLength: number;
  autumnLength: number;
  winterLength: number;
  springLength: number;
  summerLength: number;
  resourceRenewal: boolean;
  touchStones: number;
  startingItems: string;
  pauseWhenEmpty: boolean;
  maxSnapshots: number;
  worldSeed: string;
}

function configToForm(cfg: WorldConfigType): ConfigForm {
  const opts = cfg.extraOptions as Record<string, unknown> | undefined;
  return {
    worldSize: cfg.worldSize,
    daySeasonLength: cfg.daySeasonLength,
    autumnLength: cfg.autumnLength,
    winterLength: cfg.winterLength,
    springLength: cfg.springLength,
    summerLength: cfg.summerLength,
    resourceRenewal: cfg.resourceRenewal,
    touchStones: cfg.touchStones,
    startingItems: cfg.startingItems ?? '',
    pauseWhenEmpty: Boolean(opts?.pauseWhenEmpty),
    maxSnapshots: Number(opts?.maxSnapshots ?? 10),
    worldSeed: String(opts?.worldSeed ?? ''),
  };
}

export default function WorldConfigPage() {
  const [clusterList, setClusterList] = useState<Cluster[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [configLoading, setConfigLoading] = useState<boolean>(false);
  const [form, setForm] = useState<ConfigForm | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const list: Cluster[] = await clusters.list();
        setClusterList(list);
        if (list.length > 0) {
          setSelectedId(list[0].id);
        }
      } catch (error: unknown) {
        logger.error('获取集群列表失败', error as Error);
        toast.error('获取集群列表失败');
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    const load = async () => {
      try {
        setConfigLoading(true);
        const cfg: WorldConfigType = await worldConfig.get(selectedId);
        setForm(configToForm(cfg));
      } catch (error: unknown) {
        logger.error('获取世界配置失败', error as Error);
        toast.error('获取世界配置失败');
      } finally {
        setConfigLoading(false);
      }
    };
    void load();
  }, [selectedId]);

  const handleSave = async () => {
    if (!selectedId || !form) return;
    try {
      setSaving(true);
      await worldConfig.update(selectedId, {
        worldSize: form.worldSize,
        daySeasonLength: Number(form.daySeasonLength),
        autumnLength: Number(form.autumnLength),
        winterLength: Number(form.winterLength),
        springLength: Number(form.springLength),
        summerLength: Number(form.summerLength),
        resourceRenewal: form.resourceRenewal,
        touchStones: Number(form.touchStones),
        startingItems: form.startingItems,
        extraOptions: {
          pauseWhenEmpty: form.pauseWhenEmpty,
          maxSnapshots: Number(form.maxSnapshots),
          worldSeed: form.worldSeed,
        },
      });
      toast.success('配置已保存');
    } catch (error: unknown) {
      logger.error('保存世界配置失败', error as Error);
      toast.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="text-2xl font-semibold">世界配置</h1>
          <div className="w-56">
            <Select value={selectedId} onValueChange={setSelectedId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择集群" />
              </SelectTrigger>
              <SelectContent>
                {clusterList.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={handleSave} disabled={!form || saving || configLoading}>
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          保存配置
        </Button>
      </div>

      {configLoading && !form ? (
        <Card>
          <CardContent className="flex items-center justify-center py-16 text-muted-foreground">
            加载配置中...
          </CardContent>
        </Card>
      ) : !form ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Globe className="h-10 w-10 mb-3 opacity-40" />
            <div>请选择一个集群以查看和编辑世界配置</div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">基础设置</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-3">
              <div className="grid gap-2">
                <Label>世界大小</Label>
                <Select
                  value={form.worldSize}
                  onValueChange={(val: string) =>
                    setForm((f) => (f ? { ...f, worldSize: val as WorldSize } : f))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {WORLD_SIZE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-days">白天时长(天)</Label>
                <Input
                  id="wc-days"
                  type="number"
                  value={form.daySeasonLength}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, daySeasonLength: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-touch">传送石数量</Label>
                <Input
                  id="wc-touch"
                  type="number"
                  value={form.touchStones}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, touchStones: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">季节长度</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-4">
              <div className="grid gap-2">
                <Label htmlFor="wc-autumn">秋季(天)</Label>
                <Input
                  id="wc-autumn"
                  type="number"
                  value={form.autumnLength}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, autumnLength: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-winter">冬季(天)</Label>
                <Input
                  id="wc-winter"
                  type="number"
                  value={form.winterLength}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, winterLength: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-spring">春季(天)</Label>
                <Input
                  id="wc-spring"
                  type="number"
                  value={form.springLength}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, springLength: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-summer">夏季(天)</Label>
                <Input
                  id="wc-summer"
                  type="number"
                  value={form.summerLength}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, summerLength: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">高级选项</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="flex items-center justify-between rounded-md border border-border bg-muted/20 p-3">
                <div>
                  <div className="text-sm font-medium">空服务器暂停</div>
                  <div className="text-xs text-muted-foreground">
                    没有玩家时暂停世界运行
                  </div>
                </div>
                <Switch
                  checked={form.pauseWhenEmpty}
                  onCheckedChange={(v) =>
                    setForm((f) => (f ? { ...f, pauseWhenEmpty: v } : f))
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="wc-snap">最大存档数</Label>
                <Input
                  id="wc-snap"
                  type="number"
                  min={1}
                  max={100}
                  value={form.maxSnapshots}
                  onChange={(e) =>
                    setForm((f) =>
                      f ? { ...f, maxSnapshots: Number(e.target.value) } : f,
                    )
                  }
                />
              </div>
              <div className="grid gap-2 md:col-span-2">
                <Label htmlFor="wc-items">初始物品</Label>
                <Input
                  id="wc-items"
                  value={form.startingItems}
                  onChange={(e) =>
                    setForm((f) => (f ? { ...f, startingItems: e.target.value } : f))
                  }
                  placeholder="如：torch,axe,pickaxe"
                />
              </div>
              <div className="grid gap-2 md:col-span-2">
                <Label htmlFor="wc-seed">世界种子</Label>
                <Input
                  id="wc-seed"
                  value={form.worldSeed}
                  onChange={(e) =>
                    setForm((f) => (f ? { ...f, worldSeed: e.target.value } : f))
                  }
                  placeholder="留空则随机生成"
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
