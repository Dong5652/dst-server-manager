import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Server,
  PlayCircle,
  Users,
  Puzzle,
  Loader2,
  AlertCircle,
  AlertTriangle,
  Info,
} from 'lucide-react';
import * as dashboardApi from '@client/src/api/dashboard';
import type { DashboardStats, ServerLog } from '@shared/api.interface';

interface StatCardProps {
  icon: typeof Server;
  label: string;
  value: number;
  accentColor: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon: Icon, label, value, accentColor }) => {
  return (
    <div
      data-ai-section-type="card-stat"
      className="bg-card border border-border rounded-lg p-5 flex items-center gap-4"
    >
      <div
        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: `${accentColor}20`, color: accentColor }}
      >
        <Icon className="w-6 h-6" />
      </div>
      <div className="min-w-0">
        <div className="text-2xl font-bold text-foreground">{value}</div>
        <div className="text-sm text-muted-foreground">{label}</div>
      </div>
    </div>
  );
};

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'running':
      return 'bg-success';
    case 'starting':
    case 'stopping':
      return 'bg-warning';
    case 'stopped':
      return 'bg-muted-foreground';
    case 'error':
      return 'bg-destructive';
    default:
      return 'bg-muted-foreground';
  }
};

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'running':
      return '运行中';
    case 'starting':
      return '启动中';
    case 'stopping':
      return '停止中';
    case 'stopped':
      return '已停止';
    case 'error':
      return '错误';
    default:
      return status;
  }
};

const getLogLevelColor = (level: string): string => {
  switch (level) {
    case 'error':
      return 'text-destructive';
    case 'warn':
      return 'text-warning';
    case 'info':
      return 'text-info';
    case 'debug':
      return 'text-muted-foreground';
    default:
      return 'text-foreground';
  }
};

const getLogLevelIcon = (level: string): typeof Info => {
  switch (level) {
    case 'error':
      return AlertCircle;
    case 'warn':
      return AlertTriangle;
    default:
      return Info;
  }
};

const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchStats = async (): Promise<void> => {
      try {
        const data = await dashboardApi.getStats();
        setStats(data);
      } catch (err) {
        const msg = (err as Error)?.message ?? '加载失败';
        setError(msg);
        logger.error(`Dashboard stats load failed: ${msg}`);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <span className="ml-3 text-muted-foreground">加载中...</span>
      </div>
    );
  }

  if (error || !stats) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <AlertCircle className="w-10 h-10 text-destructive" />
        <p className="text-muted-foreground">{error || '加载失败'}</p>
      </div>
    );
  }

  const statCards: Array<{
    icon: typeof Server;
    label: string;
    value: number;
    color: string;
  }> = [
    {
      icon: Server,
      label: '集群总数',
      value: stats.totalClusters,
      color: 'hsl(262, 70%, 55%)',
    },
    {
      icon: PlayCircle,
      label: '运行中集群',
      value: stats.runningClusters,
      color: 'hsl(142, 70%, 45%)',
    },
    {
      icon: Users,
      label: '在线玩家总数',
      value: stats.totalOnlinePlayers,
      color: 'hsl(38, 92%, 50%)',
    },
    {
      icon: Puzzle,
      label: 'Mod 总数',
      value: stats.totalMods,
      color: 'hsl(200, 70%, 55%)',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-xl font-bold text-foreground">仪表盘</h1>
        <p className="text-sm text-muted-foreground mt-1">服务器运行总览</p>
      </div>

      {/* Stats grid */}
      <div
        data-ai-section-type="card-stat"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {statCards.map((card) => (
          <StatCard
            key={card.label}
            icon={card.icon}
            label={card.label}
            value={card.value}
            accentColor={card.color}
          />
        ))}
      </div>

      {/* Cluster status list */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h2 className="text-base font-semibold text-foreground">集群状态</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-5 py-3 font-medium text-muted-foreground">
                  集群名称
                </th>
                <th className="text-left px-5 py-3 font-medium text-muted-foreground">
                  状态
                </th>
                <th className="text-left px-5 py-3 font-medium text-muted-foreground">
                  在线人数
                </th>
              </tr>
            </thead>
            <tbody>
              {stats.clusterStatuses.length === 0 ? (
                <tr>
                  <td
                    colSpan={3}
                    className="px-5 py-8 text-center text-muted-foreground"
                  >
                    暂无集群数据
                  </td>
                </tr>
              ) : (
                stats.clusterStatuses.map((cluster) => (
                  <tr
                    key={cluster.id}
                    className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors"
                  >
                    <td className="px-5 py-3 text-foreground font-medium">
                      {cluster.name}
                    </td>
                    <td className="px-5 py-3">
                      <span className="inline-flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${getStatusColor(cluster.status)}`}
                        />
                        <span className="text-foreground">
                          {getStatusLabel(cluster.status)}
                        </span>
                      </span>
                    </td>
                    <td className="px-5 py-3 text-muted-foreground">
                      {cluster.onlineCount} 人
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent logs */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h2 className="text-base font-semibold text-foreground">最近日志</h2>
        </div>
        <div className="divide-y divide-border/50">
          {stats.recentLogs.length === 0 ? (
            <div className="px-5 py-8 text-center text-muted-foreground text-sm">
              暂无日志数据
            </div>
          ) : (
            stats.recentLogs.slice(0, 10).map((log: ServerLog) => {
              const LevelIcon = getLogLevelIcon(log.logLevel);
              return (
                <div
                  key={log.id}
                  className="px-5 py-3 flex items-start gap-3 hover:bg-muted/20 transition-colors"
                >
                  <LevelIcon
                    className={`w-4 h-4 mt-0.5 flex-shrink-0 ${getLogLevelColor(log.logLevel)}`}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="uppercase font-medium">
                        {log.logLevel}
                      </span>
                      <span>·</span>
                      <span>{log.serverType}</span>
                      <span>·</span>
                      <span>
                        {new Date(log.createdAt).toLocaleString('zh-CN')}
                      </span>
                    </div>
                    <p className="text-sm text-foreground mt-0.5 break-words">
                      {log.message}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
