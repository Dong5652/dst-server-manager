import { useEffect, useState } from 'react';
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  LayoutDashboard,
  Server,
  Globe,
  Puzzle,
  Users,
  Terminal,
  FileText,
  Activity,
  Settings,
  LogOut,
  Flame,
} from 'lucide-react';
import { getToken, removeToken } from '@client/src/api/_utils';
import * as authApi from '@client/src/api/auth';
import type { User } from '@shared/api.interface';

interface MenuItem {
  path: string;
  label: string;
  icon: typeof LayoutDashboard;
  end?: boolean;
}

const menuItems: MenuItem[] = [
  { path: '/', label: '仪表盘', icon: LayoutDashboard, end: true },
  { path: '/clusters', label: '服务器集群', icon: Server },
  { path: '/world-config', label: '世界配置', icon: Globe },
  { path: '/mods', label: 'Mod 管理', icon: Puzzle },
  { path: '/players', label: '玩家管理', icon: Users },
  { path: '/console', label: '控制台', icon: Terminal },
  { path: '/logs', label: '服务器日志', icon: FileText },
  { path: '/monitoring', label: '监控中心', icon: Activity },
  { path: '/settings', label: '系统设置', icon: Settings },
];

const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getToken();
    if (!token) {
      navigate('/login', { replace: true });
      return;
    }

    const fetchUser = async (): Promise<void> => {
      try {
        const userData: User = await authApi.me(token);
        setUser(userData);
      } catch (err) {
        logger.error(`Layout auth check failed: ${(err as Error)?.message ?? String(err)}`);
        removeToken();
        navigate('/login', { replace: true });
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [navigate, location.pathname]);

  const handleLogout = (): void => {
    removeToken();
    setUser(null);
    navigate('/login', { replace: true });
  };

  if (loading) {
    return (
      <div className="w-screen h-screen flex items-center justify-center bg-background text-foreground">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-background text-foreground">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 bg-sidebar border-r border-sidebar-border flex flex-col">
        {/* Logo */}
        <div className="h-14 flex items-center gap-2 px-5 border-b border-sidebar-border">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Flame className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sidebar-foreground text-sm">
            DST 管理系统
          </span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {menuItems.map((item: MenuItem) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground font-medium'
                      : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`
                }
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-14 flex items-center justify-between px-6 border-b border-border bg-card/50 flex-shrink-0">
          <div className="text-base font-semibold text-foreground">
            DST 服务器管理系统
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">
              {user?.displayName || user?.username || '未登录'}
            </span>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              <LogOut className="w-4 h-4" />
              登出
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
