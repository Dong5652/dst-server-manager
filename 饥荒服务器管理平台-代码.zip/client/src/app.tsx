import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';
import LoginPage from './pages/Login/LoginPage';
import DashboardPage from './pages/Dashboard/DashboardPage';
import ClustersPage from './pages/Clusters/ClustersPage';
import WorldConfigPage from './pages/WorldConfig/WorldConfigPage';
import ModsPage from './pages/Mods/ModsPage';
import PlayersPage from './pages/Players/PlayersPage';
import ConsolePage from './pages/Console/ConsolePage';
import LogsPage from './pages/Logs/LogsPage';
import MonitoringPage from './pages/Monitoring/MonitoringPage';
import SettingsPage from './pages/Settings/SettingsPage';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="clusters" element={<ClustersPage />} />
        <Route path="world-config" element={<WorldConfigPage />} />
        <Route path="mods" element={<ModsPage />} />
        <Route path="players" element={<PlayersPage />} />
        <Route path="console" element={<ConsolePage />} />
        <Route path="logs" element={<LogsPage />} />
        <Route path="monitoring" element={<MonitoringPage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
