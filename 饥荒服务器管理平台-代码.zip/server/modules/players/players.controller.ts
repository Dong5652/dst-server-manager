import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { PlayersService } from './players.service';
import type {
  Player,
  PlayerListEntry,
  AddPlayerListRequest,
} from '@shared/api.interface';

type PlayerListType = 'admin' | 'whitelist' | 'ban';

@Controller('api/players')
export class PlayersController {
  constructor(private readonly playersService: PlayersService) {}

  @Get()
  async getPlayers(
    @Query('clusterId') clusterId: string,
    @Query('onlineOnly') onlineOnly?: string,
  ): Promise<Player[]> {
    const isOnlineOnly: boolean = onlineOnly === 'true';
    return this.playersService.getPlayers(clusterId, isOnlineOnly);
  }

  @Get('lists')
  async getPlayerList(
    @Query('clusterId') clusterId: string,
    @Query('listType') listType: PlayerListType,
  ): Promise<PlayerListEntry[]> {
    return this.playersService.getPlayerList(clusterId, listType);
  }

  @Post('lists')
  async addPlayerList(@Body() dto: AddPlayerListRequest): Promise<PlayerListEntry> {
    return this.playersService.addPlayerList(dto);
  }

  @Delete('lists/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async removePlayerList(@Param('id') id: string): Promise<void> {
    await this.playersService.removePlayerList(id);
  }

  @Post(':id/kick')
  async kickPlayer(@Param('id') id: string): Promise<Player> {
    return this.playersService.kickPlayer(id);
  }
}
