import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc } from 'drizzle-orm';
import { dstPlayers, dstPlayerLists } from '@server/database/schema';
import type {
  Player,
  PlayerListEntry,
  AddPlayerListRequest,
} from '@shared/api.interface';

type PlayerListType = 'admin' | 'whitelist' | 'ban';

function mapPlayer(row: typeof dstPlayers.$inferSelect): Player {
  return {
    id: row.id,
    clusterId: row.clusterId,
    kleiId: row.kleiId,
    playerName: row.playerName,
    isOnline: row.isOnline,
    lastJoinAt: row.lastJoinAt ? row.lastJoinAt.toISOString() : null,
    playtimeSeconds: row.playtimeSeconds,
    characterUsed: row.characterUsed,
  };
}

function mapPlayerListEntry(row: typeof dstPlayerLists.$inferSelect): PlayerListEntry {
  return {
    id: row.id,
    clusterId: row.clusterId,
    listType: row.listType as PlayerListType,
    kleiId: row.kleiId,
    playerName: row.playerName,
    reason: row.reason,
    addedAt: row.addedAt.toISOString(),
  };
}

@Injectable()
export class PlayersService {
  private readonly logger = new Logger(PlayersService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async getPlayers(clusterId: string, onlineOnly: boolean): Promise<Player[]> {
    try {
      const conditions = [eq(dstPlayers.clusterId, clusterId)];
      if (onlineOnly) {
        conditions.push(eq(dstPlayers.isOnline, true));
      }

      const query = conditions.length > 1
        ? this.db.select().from(dstPlayers).where(and(...conditions))
        : this.db.select().from(dstPlayers).where(conditions[0]);

      const rows: (typeof dstPlayers.$inferSelect)[] = await query
        .orderBy(desc(dstPlayers.lastJoinAt));

      return rows.map((row: typeof dstPlayers.$inferSelect) => mapPlayer(row));
    } catch (error) {
      this.logger.error(`获取玩家列表失败: clusterId=${clusterId}`, error as string);
      throw error;
    }
  }

  async getPlayerList(clusterId: string, listType: PlayerListType): Promise<PlayerListEntry[]> {
    try {
      const rows: (typeof dstPlayerLists.$inferSelect)[] = await this.db
        .select()
        .from(dstPlayerLists)
        .where(
          and(
            eq(dstPlayerLists.clusterId, clusterId),
            eq(dstPlayerLists.listType, listType),
          ),
        )
        .orderBy(desc(dstPlayerLists.addedAt));

      return rows.map((row: typeof dstPlayerLists.$inferSelect) => mapPlayerListEntry(row));
    } catch (error) {
      this.logger.error(
        `获取玩家名单失败: clusterId=${clusterId}, listType=${listType}`,
        error as string,
      );
      throw error;
    }
  }

  async addPlayerList(dto: AddPlayerListRequest): Promise<PlayerListEntry> {
    try {
      const existing: (typeof dstPlayerLists.$inferSelect)[] = await this.db
        .select()
        .from(dstPlayerLists)
        .where(
          and(
            eq(dstPlayerLists.clusterId, dto.clusterId),
            eq(dstPlayerLists.listType, dto.listType),
            eq(dstPlayerLists.kleiId, dto.kleiId),
          ),
        )
        .limit(1);

      if (existing.length > 0) {
        throw new ConflictException('该玩家已在对应名单中');
      }

      const inserted: (typeof dstPlayerLists.$inferSelect)[] = await this.db
        .insert(dstPlayerLists)
        .values({
          clusterId: dto.clusterId,
          listType: dto.listType,
          kleiId: dto.kleiId,
          playerName: dto.playerName,
          reason: dto.reason,
        })
        .returning();

      return mapPlayerListEntry(inserted[0]);
    } catch (error) {
      if (error instanceof ConflictException) throw error;
      this.logger.error(`添加玩家名单失败: ${JSON.stringify(dto)}`, error as string);
      throw error;
    }
  }

  async removePlayerList(id: string): Promise<void> {
    try {
      const deleted: { id: string }[] = await this.db
        .delete(dstPlayerLists)
        .where(eq(dstPlayerLists.id, id))
        .returning({ id: dstPlayerLists.id });

      if (deleted.length === 0) {
        throw new NotFoundException('名单记录不存在');
      }
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error(`移除玩家名单失败: id=${id}`, error as string);
      throw error;
    }
  }

  async kickPlayer(id: string): Promise<Player> {
    try {
      const existing: (typeof dstPlayers.$inferSelect)[] = await this.db
        .select()
        .from(dstPlayers)
        .where(eq(dstPlayers.id, id))
        .limit(1);

      if (existing.length === 0) {
        throw new NotFoundException('玩家不存在');
      }

      const player: typeof dstPlayers.$inferSelect = existing[0];

      const updated: (typeof dstPlayers.$inferSelect)[] = await this.db
        .update(dstPlayers)
        .set({ isOnline: false })
        .where(eq(dstPlayers.id, id))
        .returning();

      this.logger.log(
        `踢出玩家: id=${id}, kleiId=${player.kleiId}, playerName=${player.playerName}`,
      );

      const banExisting: (typeof dstPlayerLists.$inferSelect)[] = await this.db
        .select()
        .from(dstPlayerLists)
        .where(
          and(
            eq(dstPlayerLists.clusterId, player.clusterId),
            eq(dstPlayerLists.listType, 'ban'),
            eq(dstPlayerLists.kleiId, player.kleiId),
          ),
        )
        .limit(1);

      if (banExisting.length === 0) {
        await this.db.insert(dstPlayerLists).values({
          clusterId: player.clusterId,
          listType: 'ban',
          kleiId: player.kleiId,
          playerName: player.playerName,
          reason: '踢出玩家自动封禁',
        });
      }

      return mapPlayer(updated[0]);
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error(`踢出玩家失败: id=${id}`, error as string);
      throw error;
    }
  }
}
