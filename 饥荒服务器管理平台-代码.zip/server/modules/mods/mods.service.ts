import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc } from 'drizzle-orm';
import { dstMods } from '@server/database/schema';
import type { Mod, AddModRequest, UpdateModRequest } from '@shared/api.interface';

interface ModConfigOption {
  name: string;
  value: string | number | boolean;
}

interface ModConfig {
  options: ModConfigOption[];
}

function normalizeModConfig(raw: unknown): ModConfig {
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    const obj = raw as Record<string, unknown>;
    if (Array.isArray(obj.options)) {
      return { options: obj.options as ModConfigOption[] };
    }
  }
  return { options: [] };
}

function mapMod(row: typeof dstMods.$inferSelect): Mod {
  return {
    id: row.id,
    clusterId: row.clusterId,
    workshopId: row.workshopId,
    modName: row.modName,
    description: row.description,
    author: row.author,
    enabled: row.enabled,
    priority: row.priority,
    modConfig: normalizeModConfig(row.modConfig),
    createdAt: row.createdAt.toISOString(),
  };
}

@Injectable()
export class ModsService {
  private readonly logger = new Logger(ModsService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async getMods(clusterId: string): Promise<Mod[]> {
    try {
      const rows: (typeof dstMods.$inferSelect)[] = await this.db
        .select()
        .from(dstMods)
        .where(eq(dstMods.clusterId, clusterId))
        .orderBy(desc(dstMods.priority));
      return rows.map((row: typeof dstMods.$inferSelect) => mapMod(row));
    } catch (error) {
      this.logger.error(`获取 Mod 列表失败: clusterId=${clusterId}`, error as string);
      throw error;
    }
  }

  async addMod(dto: AddModRequest): Promise<Mod> {
    try {
      const existing: (typeof dstMods.$inferSelect)[] = await this.db
        .select()
        .from(dstMods)
        .where(
          and(
            eq(dstMods.clusterId, dto.clusterId),
            eq(dstMods.workshopId, dto.workshopId),
          ),
        )
        .limit(1);

      if (existing.length > 0) {
        throw new ConflictException('该集群下已存在相同 workshopId 的 Mod');
      }

      const inserted: (typeof dstMods.$inferSelect)[] = await this.db
        .insert(dstMods)
        .values({
          clusterId: dto.clusterId,
          workshopId: dto.workshopId,
          modName: dto.modName,
          description: dto.description,
          author: dto.author,
          enabled: false,
          priority: 0,
          modConfig: { options: [] },
        })
        .returning();

      return mapMod(inserted[0]);
    } catch (error) {
      if (error instanceof ConflictException) throw error;
      this.logger.error(`添加 Mod 失败: ${JSON.stringify(dto)}`, error as string);
      throw error;
    }
  }

  async updateMod(id: string, dto: UpdateModRequest): Promise<Mod> {
    try {
      const patch: Partial<typeof dstMods.$inferInsert> = {};
      if (dto.enabled !== undefined) patch.enabled = dto.enabled;
      if (dto.priority !== undefined) patch.priority = dto.priority;
      if (dto.modConfig !== undefined) patch.modConfig = dto.modConfig as unknown as Record<string, unknown>;

      if (Object.keys(patch).length === 0) {
        throw new BadRequestException('未提供可更新字段');
      }

      const updated: (typeof dstMods.$inferSelect)[] = await this.db
        .update(dstMods)
        .set(patch)
        .where(eq(dstMods.id, id))
        .returning();

      if (updated.length === 0) {
        throw new NotFoundException('Mod 不存在');
      }

      return mapMod(updated[0]);
    } catch (error) {
      if (error instanceof NotFoundException || error instanceof BadRequestException) throw error;
      this.logger.error(`更新 Mod 失败: id=${id}`, error as string);
      throw error;
    }
  }

  async deleteMod(id: string): Promise<void> {
    try {
      const deleted: { id: string }[] = await this.db
        .delete(dstMods)
        .where(eq(dstMods.id, id))
        .returning({ id: dstMods.id });

      if (deleted.length === 0) {
        throw new NotFoundException('Mod 不存在');
      }
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error(`删除 Mod 失败: id=${id}`, error as string);
      throw error;
    }
  }

  async toggleMod(id: string): Promise<Mod> {
    try {
      const existing: (typeof dstMods.$inferSelect)[] = await this.db
        .select()
        .from(dstMods)
        .where(eq(dstMods.id, id))
        .limit(1);

      if (existing.length === 0) {
        throw new NotFoundException('Mod 不存在');
      }

      const updated: (typeof dstMods.$inferSelect)[] = await this.db
        .update(dstMods)
        .set({ enabled: !existing[0].enabled })
        .where(eq(dstMods.id, id))
        .returning();

      return mapMod(updated[0]);
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error(`切换 Mod 状态失败: id=${id}`, error as string);
      throw error;
    }
  }

  async reorderMods(clusterId: string, orderedIds: string[]): Promise<Mod[]> {
    try {
      const len: number = orderedIds.length;
      for (let i = 0; i < len; i += 1) {
        const priority: number = (len - i) * 10;
        await this.db
          .update(dstMods)
          .set({ priority })
          .where(
            and(
              eq(dstMods.id, orderedIds[i]),
              eq(dstMods.clusterId, clusterId),
            ),
          );
      }

      return this.getMods(clusterId);
    } catch (error) {
      this.logger.error(`重排序 Mod 失败: clusterId=${clusterId}`, error as string);
      throw error;
    }
  }
}
