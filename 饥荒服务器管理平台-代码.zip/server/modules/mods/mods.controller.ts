import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ModsService } from './mods.service';
import type { Mod, AddModRequest, UpdateModRequest } from '@shared/api.interface';

interface ReorderModsRequest {
  clusterId: string;
  orderedIds: string[];
}

@Controller('api/mods')
export class ModsController {
  constructor(private readonly modsService: ModsService) {}

  @Get()
  async getMods(@Query('clusterId') clusterId: string): Promise<Mod[]> {
    return this.modsService.getMods(clusterId);
  }

  @Post()
  async addMod(@Body() dto: AddModRequest): Promise<Mod> {
    return this.modsService.addMod(dto);
  }

  @Patch(':id')
  async updateMod(
    @Param('id') id: string,
    @Body() dto: UpdateModRequest,
  ): Promise<Mod> {
    return this.modsService.updateMod(id, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteMod(@Param('id') id: string): Promise<void> {
    await this.modsService.deleteMod(id);
  }

  @Post(':id/toggle')
  async toggleMod(@Param('id') id: string): Promise<Mod> {
    return this.modsService.toggleMod(id);
  }

  @Post('reorder')
  async reorderMods(@Body() body: ReorderModsRequest): Promise<Mod[]> {
    return this.modsService.reorderMods(body.clusterId, body.orderedIds);
  }
}
