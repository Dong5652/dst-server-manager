import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
} from '@nestjs/common';
import { ClustersService } from './clusters.service';
import type {
  Cluster,
  ClusterListResponse,
  CreateClusterRequest,
  UpdateClusterRequest,
} from '@shared/api.interface';

@Controller('api/clusters')
export class ClustersController {
  constructor(private readonly clustersService: ClustersService) {}

  @Get()
  async findAll(@Query('status') status?: string): Promise<ClusterListResponse> {
    return this.clustersService.findAll(status);
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Cluster> {
    return this.clustersService.findOne(id);
  }

  @Post()
  async create(@Body() dto: CreateClusterRequest): Promise<Cluster> {
    return this.clustersService.create(dto);
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateClusterRequest,
  ): Promise<Cluster> {
    return this.clustersService.update(id, dto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.clustersService.remove(id);
    return { success: true };
  }

  @Post(':id/start')
  async start(@Param('id') id: string): Promise<Cluster> {
    return this.clustersService.start(id);
  }

  @Post(':id/stop')
  async stop(@Param('id') id: string): Promise<Cluster> {
    return this.clustersService.stop(id);
  }

  @Post(':id/restart')
  async restart(@Param('id') id: string): Promise<Cluster> {
    return this.clustersService.restart(id);
  }
}
