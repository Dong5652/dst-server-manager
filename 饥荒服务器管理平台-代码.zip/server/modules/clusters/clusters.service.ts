import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, desc, inArray } from 'drizzle-orm';
import type { Cluster, Server, CreateClusterRequest, UpdateClusterRequest, ClusterListResponse } from '@shared/api.interface';
import { dstClusters, dstServers, dstWorldConfig, dstServerLogs } from '@server/database/schema';

type ClusterStatus = Cluster['status'];
type ServerStatus = Server['status'];
type ServerType = Server['serverType'];

@Injectable()
export class ClustersService {
  private readonly logger = new Logger(ClustersService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private mapCluster(row: typeof dstClusters.$inferSelect, servers: Server[] = []): Cluster {
    return {
      id: row.id,
      name: row.name,
      description: row.description ?? null,
      status: row.status as ClusterStatus,
      gameMode: row.gameMode as Cluster['gameMode'],
      maxPlayers: row.maxPlayers,
      hasCaves: row.hasCaves,
      steamToken: row.steamToken ?? null,
      clusterToken: row.clusterToken ?? null,
      createdAt: row.createdAt.toISOString(),
      servers,
    };
  }

  private mapServer(row: typeof dstServers.$inferSelect): Server {
    return {
      id: row.id,
      clusterId: row.clusterId,
      serverType: row.serverType as ServerType,
      port: row.port,
      pid: row.pid ?? null,
      status: row.status as ServerStatus,
      memoryMb: row.memoryMb ?? 0,
      lastHeartbeat: row.lastHeartbeat ? row.lastHeartbeat.toISOString() : null,
      startedAt: row.startedAt ? row.startedAt.toISOString() : null,
    };
  }

  private async loadServersForClusters(clusterIds: string[]): Promise<Map<string, Server[]>> {
    const serverRows: (typeof dstServers.$inferSelect)[] = await this.db
      .select()
      .from(dstServers)
      .where(inArray(dstServers.clusterId, clusterIds))
      .orderBy(dstServers.port);

    const byCluster = new Map<string, Server[]>();
    for (const row of serverRows) {
      const clusterId: string = row.clusterId;
      const list = byCluster.get(clusterId) ?? [];
      list.push(this.mapServer(row));
      byCluster.set(clusterId, list);
    }
    return byCluster;
  }

  async findAll(status?: string): Promise<ClusterListResponse> {
    const conditions = [];
    if (status) {
      conditions.push(eq(dstClusters.status, status));
    }

    const baseQuery = conditions.length > 0
      ? this.db.select().from(dstClusters).where(and(...conditions))
      : this.db.select().from(dstClusters);

    const clusterRows = await baseQuery.orderBy(desc(dstClusters.createdAt));

    const countResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(dstClusters).where(and(...conditions))
      : await this.db.select({ count: count() }).from(dstClusters);

    const total: number = Number(countResult[0]?.count ?? 0);

    if (clusterRows.length === 0) {
      return { items: [], total };
    }

    const clusterIds: string[] = clusterRows.map((r: typeof dstClusters.$inferSelect) => r.id);
    const serversByCluster = await this.loadServersForClusters(clusterIds);

    const items: Cluster[] = clusterRows.map((row: typeof dstClusters.$inferSelect) =>
      this.mapCluster(row, serversByCluster.get(row.id) ?? []),
    );

    return { items, total };
  }

  async findOne(id: string): Promise<Cluster> {
    const clusterRows = await this.db
      .select()
      .from(dstClusters)
      .where(eq(dstClusters.id, id))
      .limit(1);

    if (clusterRows.length === 0) {
      throw new NotFoundException('集群不存在');
    }

    const serverRows = await this.db
      .select()
      .from(dstServers)
      .where(eq(dstServers.clusterId, id))
      .orderBy(dstServers.port);

    const servers: Server[] = serverRows.map((r: typeof dstServers.$inferSelect) => this.mapServer(r));
    return this.mapCluster(clusterRows[0], servers);
  }

  private async getNextBasePort(): Promise<number> {
    const result = await this.db
      .select({ maxPort: dstServers.port })
      .from(dstServers)
      .orderBy(desc(dstServers.port))
      .limit(1);

    const maxPort: number | undefined = result[0]?.maxPort;
    if (maxPort === undefined) {
      return 10999;
    }
    return maxPort + 1;
  }

  async create(dto: CreateClusterRequest): Promise<Cluster> {
    const basePort = await this.getNextBasePort();

    const created = await this.db.transaction(async (tx) => {
      const clusterRows = await tx
        .insert(dstClusters)
        .values({
          name: dto.name,
          description: dto.description,
          status: 'stopped',
          gameMode: dto.gameMode,
          maxPlayers: dto.maxPlayers,
          hasCaves: dto.hasCaves,
          clusterToken: dto.clusterToken,
        })
        .returning();

      const cluster = clusterRows[0];
      if (!cluster) {
        throw new BadRequestException('创建集群失败');
      }

      const serverValues: Array<typeof dstServers.$inferInsert> = [
        {
          clusterId: cluster.id,
          serverType: 'master',
          port: basePort,
          status: 'stopped',
          memoryMb: 0,
        },
      ];

      if (dto.hasCaves) {
        serverValues.push({
          clusterId: cluster.id,
          serverType: 'caves',
          port: basePort + 1,
          status: 'stopped',
          memoryMb: 0,
        });
      }

      await tx.insert(dstServers).values(serverValues);

      const defaultExtraOptions = {
        pauseWhenEmpty: true,
        maxSnapshots: 6,
        worldSeed: '',
      };

      await tx.insert(dstWorldConfig).values({
        clusterId: cluster.id,
        extraOptions: defaultExtraOptions,
      });

      return cluster;
    });

    this.logger.log(`创建集群: ${created.id} (${created.name})`);
    return this.findOne(created.id);
  }

  async update(id: string, dto: UpdateClusterRequest): Promise<Cluster> {
    const patch: Partial<typeof dstClusters.$inferInsert> = {};
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.description !== undefined) patch.description = dto.description;
    if (dto.gameMode !== undefined) patch.gameMode = dto.gameMode;
    if (dto.maxPlayers !== undefined) patch.maxPlayers = dto.maxPlayers;
    if (dto.hasCaves !== undefined) patch.hasCaves = dto.hasCaves;
    if (dto.clusterToken !== undefined) patch.clusterToken = dto.clusterToken;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(dstClusters)
      .set(patch)
      .where(eq(dstClusters.id, id))
      .returning({ id: dstClusters.id });

    if (updated.length === 0) {
      throw new NotFoundException('集群不存在');
    }

    return this.findOne(id);
  }

  async remove(id: string): Promise<void> {
    const deleted = await this.db
      .delete(dstClusters)
      .where(eq(dstClusters.id, id))
      .returning({ id: dstClusters.id });

    if (deleted.length === 0) {
      throw new NotFoundException('集群不存在');
    }

    this.logger.log(`删除集群: ${id}`);
  }

  private randomPid(): number {
    return Math.floor(Math.random() * 90000) + 10000;
  }

  private randomMemory(): number {
    return Math.floor(Math.random() * 401) + 300;
  }

  private async writeLog(clusterId: string, serverType: ServerType, level: string, message: string): Promise<void> {
    await this.db.insert(dstServerLogs).values({
      clusterId,
      serverType,
      logLevel: level,
      message,
      source: 'manager',
    });
  }

  async start(id: string): Promise<Cluster> {
    const cluster = await this.findOne(id);

    const now = new Date();
    const serverList = cluster.servers ?? [];

    await this.db.transaction(async (tx) => {
      await tx
        .update(dstClusters)
        .set({ status: 'starting' })
        .where(eq(dstClusters.id, id));

      await tx
        .update(dstServers)
        .set({ status: 'starting' })
        .where(eq(dstServers.clusterId, id));

      for (const srv of serverList) {
        const pid = this.randomPid();
        const memoryMb = this.randomMemory();
        await tx
          .update(dstServers)
          .set({
            status: 'running',
            pid,
            memoryMb,
            lastHeartbeat: now,
            startedAt: now,
          })
          .where(eq(dstServers.id, srv.id));

        await tx.insert(dstServerLogs).values({
          clusterId: id,
          serverType: srv.serverType,
          logLevel: 'info',
          message: `服务器已启动，PID: ${pid}`,
          source: 'manager',
        });
      }

      await tx
        .update(dstClusters)
        .set({ status: 'running' })
        .where(eq(dstClusters.id, id));

      await tx.insert(dstServerLogs).values({
        clusterId: id,
        serverType: 'master',
        logLevel: 'info',
        message: '集群启动完成',
        source: 'manager',
      });
    });

    this.logger.log(`启动集群: ${id}`);
    return this.findOne(id);
  }

  async stop(id: string): Promise<Cluster> {
    const cluster = await this.findOne(id);
    const serverList = cluster.servers ?? [];

    await this.db.transaction(async (tx) => {
      await tx
        .update(dstClusters)
        .set({ status: 'stopping' })
        .where(eq(dstClusters.id, id));

      await tx
        .update(dstServers)
        .set({ status: 'stopping' })
        .where(eq(dstServers.clusterId, id));

      for (const srv of serverList) {
        await tx
          .update(dstServers)
          .set({
            status: 'stopped',
            pid: null,
            memoryMb: 0,
            lastHeartbeat: null,
            startedAt: null,
          })
          .where(eq(dstServers.id, srv.id));

        await tx.insert(dstServerLogs).values({
          clusterId: id,
          serverType: srv.serverType,
          logLevel: 'info',
          message: '服务器已停止',
          source: 'manager',
        });
      }

      await tx
        .update(dstClusters)
        .set({ status: 'stopped' })
        .where(eq(dstClusters.id, id));

      await tx.insert(dstServerLogs).values({
        clusterId: id,
        serverType: 'master',
        logLevel: 'info',
        message: '集群已停止',
        source: 'manager',
      });
    });

    this.logger.log(`停止集群: ${id}`);
    return this.findOne(id);
  }

  async restart(id: string): Promise<Cluster> {
    await this.stop(id);
    return this.start(id);
  }
}
