import { Controller, Get, Query } from '@nestjs/common';
import { MonitoringService } from './monitoring.service';
import type { MonitoringOverview, MonitoringStat } from '@shared/api.interface';

@Controller('api/monitoring')
export class MonitoringController {
  constructor(private readonly monitoringService: MonitoringService) {}

  @Get('overview')
  async getOverview(
    @Query('clusterId') clusterId: string,
  ): Promise<MonitoringOverview> {
    return this.monitoringService.getOverview(clusterId);
  }

  @Get('history')
  async getHistory(
    @Query('clusterId') clusterId: string,
    @Query('hours') hours?: string,
  ): Promise<MonitoringStat[]> {
    const hoursNum: number = hours ? parseInt(hours, 10) : 24;
    return this.monitoringService.getHistory(clusterId, hoursNum);
  }
}
