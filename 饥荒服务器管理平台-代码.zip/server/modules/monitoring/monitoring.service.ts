import { Injectable, Inject, Logger, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gte, desc, asc, count, sql, sum } from 'drizzle-orm';
import { dstMonitoringStats, dstServers, dstPlayers } from '@server/database/schema';
import type { MonitoringOverview, MonitoringStat } from '@shared/api.interface';

@Injectable()
export class MonitoringService {
  private readonly logger = new Logger(MonitoringService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getOverview(clusterId: string): Promise<MonitoringOverview> {
    if (!clusterId) {
      throw new BadRequestException('clusterId 不能为空');
    }

    try {
      // 在线人数
      const onlineCountResult = await this.db
        .select({ count: count() })
        .from(dstPlayers)
        .where(and(eq(dstPlayers.clusterId, clusterId), eq(dstPlayers.isOnline, true)));
      const onlineCount: number = Number(onlineCountResult[0]?.count ?? 0);

      // 内存占用汇总
      const memoryResult = await this.db
        .select({ total: sum(dstServers.memoryMb) })
        .from(dstServers)
        .where(eq(dstServers.clusterId, clusterId));
      const memoryMb: number = Number(memoryResult[0]?.total ?? 0);

      // 估算 CPU（随机 10-50）
      const cpuPercent: number = Math.floor(Math.random() * 41) + 10;

      // 运行时长
      const servers = await this.db
        .select({ status: dstServers.status, startedAt: dstServers.startedAt })
        .from(dstServers)
        .where(eq(dstServers.clusterId, clusterId));

      let uptimeSeconds: number = 0;
      const runningServer = servers.find((s) => s.status === 'running');
      if (runningServer && runningServer.startedAt) {
        uptimeSeconds = Math.floor(
          (Date.now() - runningServer.startedAt.getTime()) / 1000,
        );
      }

      // 最近 24 条监控统计数据（按时间升序）
      const historyRows = await this.db
        .select()
        .from(dstMonitoringStats)
        .where(eq(dstMonitoringStats.clusterId, clusterId))
        .orderBy(desc(dstMonitoringStats.createdAt))
        .limit(24);

      const history: MonitoringStat[] = historyRows
        .reverse()
        .map((row) => ({
          id: row.id,
          clusterId: row.clusterId,
          onlineCount: row.onlineCount,
          memoryMb: row.memoryMb,
          cpuPercent: row.cpuPercent,
          createdAt: row.createdAt.toISOString(),
        }));

      return {
        onlineCount,
        memoryMb,
        cpuPercent,
        uptimeSeconds,
        history,
      };
    } catch (error) {
      this.logger.error(`获取监控概览失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async getHistory(clusterId: string, hours: number): Promise<MonitoringStat[]> {
    if (!clusterId) {
      throw new BadRequestException('clusterId 不能为空');
    }

    try {
      const since: Date = new Date(Date.now() - hours * 60 * 60 * 1000);

      const rows = await this.db
        .select()
        .from(dstMonitoringStats)
        .where(and(
          eq(dstMonitoringStats.clusterId, clusterId),
          gte(dstMonitoringStats.createdAt, since),
        ))
        .orderBy(asc(dstMonitoringStats.createdAt));

      return rows.map((row) => ({
        id: row.id,
        clusterId: row.clusterId,
        onlineCount: row.onlineCount,
        memoryMb: row.memoryMb,
        cpuPercent: row.cpuPercent,
        createdAt: row.createdAt.toISOString(),
      }));
    } catch (error) {
      this.logger.error(`获取监控历史失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }
}
