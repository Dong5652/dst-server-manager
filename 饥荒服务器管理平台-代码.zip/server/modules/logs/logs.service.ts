import { Injectable, Inject, Logger, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, like } from 'drizzle-orm';
import { dstServerLogs } from '@server/database/schema';
import type { ServerLog } from '@shared/api.interface';

@Injectable()
export class LogsService {
  private readonly logger = new Logger(LogsService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getLogs(
    clusterId: string,
    serverType?: string,
    logLevel?: string,
    keyword?: string,
    limit: number = 100,
  ): Promise<ServerLog[]> {
    if (!clusterId) {
      throw new BadRequestException('clusterId 不能为空');
    }

    const safeLimit: number = Math.min(limit, 500);

    try {
      const conditions = [eq(dstServerLogs.clusterId, clusterId)];

      if (serverType) {
        conditions.push(eq(dstServerLogs.serverType, serverType));
      }
      if (logLevel) {
        conditions.push(eq(dstServerLogs.logLevel, logLevel));
      }
      if (keyword) {
        conditions.push(like(dstServerLogs.message, `%${keyword}%`));
      }

      const rows = await this.db
        .select()
        .from(dstServerLogs)
        .where(and(...conditions))
        .orderBy(desc(dstServerLogs.createdAt))
        .limit(safeLimit);

      return rows.map((row) => ({
        id: row.id,
        clusterId: row.clusterId,
        serverType: row.serverType as 'master' | 'caves',
        logLevel: row.logLevel as 'info' | 'warn' | 'error' | 'debug',
        message: row.message,
        source: row.source,
        createdAt: row.createdAt.toISOString(),
      }));
    } catch (error) {
      this.logger.error(`获取服务器日志失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }
}
