import { Controller, Get, Query } from '@nestjs/common';
import { LogsService } from './logs.service';
import type { ServerLog } from '@shared/api.interface';

@Controller('api/logs')
export class LogsController {
  constructor(private readonly logsService: LogsService) {}

  @Get()
  async getLogs(
    @Query('clusterId') clusterId: string,
    @Query('serverType') serverType?: string,
    @Query('logLevel') logLevel?: string,
    @Query('keyword') keyword?: string,
    @Query('limit') limit?: string,
  ): Promise<ServerLog[]> {
    const limitNum: number = limit ? parseInt(limit, 10) : 100;
    return this.logsService.getLogs(clusterId, serverType, logLevel, keyword, limitNum);
  }
}
