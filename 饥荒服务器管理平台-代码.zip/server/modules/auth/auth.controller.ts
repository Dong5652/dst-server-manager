import {
  Controller,
  Post,
  Get,
  Body,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import type { Request } from 'express';
import { AuthService } from './auth.service';
import type {
  User,
  LoginRequest,
  LoginResponse,
  RegisterRequest,
} from '@shared/api.interface';

@Controller('api/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * 从 Authorization header 中解析 token (userId)
   */
  private extractToken(req: Request): string {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('未提供认证令牌');
    }
    const token = authHeader.slice(7).trim();
    if (!token) {
      throw new UnauthorizedException('令牌无效');
    }
    return token;
  }

  @Post('register')
  async register(@Body() body: RegisterRequest): Promise<User> {
    return this.authService.register(
      body.username,
      body.password,
      body.displayName,
    );
  }

  @Post('login')
  async login(@Body() body: LoginRequest): Promise<LoginResponse> {
    return this.authService.login(body.username, body.password);
  }

  @Get('me')
  async getMe(@Req() req: Request): Promise<User> {
    const userId = this.extractToken(req);
    return this.authService.getCurrentUser(userId);
  }
}
