import {
  Injectable,
  Inject,
  Logger,
  ConflictException,
  UnauthorizedException,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq } from 'drizzle-orm';
import { scryptSync, randomBytes, timingSafeEqual } from 'node:crypto';
import { dstUsers } from '@server/database/schema';
import type { User, LoginResponse } from '@shared/api.interface';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * 使用 scrypt 生成密码 hash
   * 格式: <salt>:<hash> (均为 hex)
   */
  private hashPassword(password: string): string {
    const salt = randomBytes(16).toString('hex');
    const derivedKey = scryptSync(password, salt, 64) as Buffer;
    return `${salt}:${derivedKey.toString('hex')}`;
  }

  private verifyPassword(password: string, storedHash: string): boolean {
    try {
      const [salt, hashHex] = storedHash.split(':');
      if (!salt || !hashHex) return false;
      const derivedKey = scryptSync(password, salt, 64) as Buffer;
      const storedBuffer = Buffer.from(hashHex, 'hex');
      if (derivedKey.length !== storedBuffer.length) return false;
      return timingSafeEqual(derivedKey, storedBuffer);
    } catch {
      return false;
    }
  }

  private toUserDto(row: typeof dstUsers.$inferSelect): User {
    return {
      id: row.id,
      username: row.username,
      role: (row.role as 'admin' | 'user') ?? 'user',
      displayName: row.displayName ?? null,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async register(
    username: string,
    password: string,
    displayName?: string,
  ): Promise<User> {
    // 检查用户名是否已存在
    const existing = await this.db
      .select({ id: dstUsers.id })
      .from(dstUsers)
      .where(eq(dstUsers.username, username))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('用户名已存在');
    }

    const passwordHash = this.hashPassword(password);

    const inserted = await this.db
      .insert(dstUsers)
      .values({
        username,
        passwordHash,
        role: 'user',
        displayName: displayName ?? null,
      })
      .returning();

    this.logger.log(`用户注册成功: ${username}`);
    return this.toUserDto(inserted[0]);
  }

  async login(username: string, password: string): Promise<LoginResponse> {
    const rows = await this.db
      .select()
      .from(dstUsers)
      .where(eq(dstUsers.username, username))
      .limit(1);

    if (rows.length === 0) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const userRow = rows[0];
    if (!this.verifyPassword(password, userRow.passwordHash)) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const user = this.toUserDto(userRow);
    this.logger.log(`用户登录: ${username}`);

    return {
      user,
      token: user.id, // 简单方案：token = userId
    };
  }

  async getCurrentUser(userId: string): Promise<User> {
    const rows = await this.db
      .select()
      .from(dstUsers)
      .where(eq(dstUsers.id, userId))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return this.toUserDto(rows[0]);
  }
}
