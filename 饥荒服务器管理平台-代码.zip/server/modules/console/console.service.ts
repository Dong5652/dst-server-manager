import { Injectable, Inject, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, desc } from 'drizzle-orm';
import { dstConsoleCommands } from '@server/database/schema';
import type { ConsoleCommand, ExecuteCommandRequest } from '@shared/api.interface';

@Injectable()
export class ConsoleService {
  private readonly logger = new Logger(ConsoleService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  private simulateCommandResult(command: string): string {
    const trimmed = command.trim();
    if (/^c_announce\s*\(/i.test(trimmed)) {
      return '公告已发送';
    }
    if (/^c_save\s*\(\s*\)/i.test(trimmed)) {
      return '世界已保存';
    }
    if (/^c_regenerateworld\s*\(/i.test(trimmed)) {
      return '世界将在 60 秒后重新生成';
    }
    if (/^c_rollback\s*\(/i.test(trimmed)) {
      return '已回滚到指定存档';
    }
    if (/^TheWorld:PushEvent\s*\(/i.test(trimmed)) {
      return '事件已推送';
    }
    return '命令已发送至服务器';
  }

  async executeCommand(dto: ExecuteCommandRequest, executedBy: string): Promise<ConsoleCommand> {
    try {
      const result: string = this.simulateCommandResult(dto.command);

      const inserted = await this.db
        .insert(dstConsoleCommands)
        .values({
          clusterId: dto.clusterId,
          command: dto.command,
          result,
          executedBy,
        })
        .returning();

      const row = inserted[0];
      return {
        id: row.id,
        clusterId: row.clusterId,
        command: row.command,
        result: row.result,
        executedBy: row.executedBy,
        createdAt: row.createdAt.toISOString(),
      };
    } catch (error) {
      this.logger.error(`执行控制台命令失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async getHistory(clusterId: string, limit: number): Promise<ConsoleCommand[]> {
    try {
      const rows = await this.db
        .select()
        .from(dstConsoleCommands)
        .where(eq(dstConsoleCommands.clusterId, clusterId))
        .orderBy(desc(dstConsoleCommands.createdAt))
        .limit(limit);

      return rows.map((row) => ({
        id: row.id,
        clusterId: row.clusterId,
        command: row.command,
        result: row.result,
        executedBy: row.executedBy,
        createdAt: row.createdAt.toISOString(),
      }));
    } catch (error) {
      this.logger.error(`获取命令历史失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }
}
