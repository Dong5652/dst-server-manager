import { Controller, Post, Get, Body, Query, Req } from '@nestjs/common';
import type { Request } from 'express';
import { ConsoleService } from './console.service';
import type { ConsoleCommand, ExecuteCommandRequest } from '@shared/api.interface';

@Controller('api/console')
export class ConsoleController {
  constructor(private readonly consoleService: ConsoleService) {}

  @Post('execute')
  async executeCommand(
    @Req() req: Request,
    @Body() body: ExecuteCommandRequest,
  ): Promise<ConsoleCommand> {
    const { userId } = req.userContext;
    const executedBy: string = userId || 'admin';
    return this.consoleService.executeCommand(body, executedBy);
  }

  @Get('history')
  async getHistory(
    @Query('clusterId') clusterId: string,
    @Query('limit') limit?: string,
  ): Promise<ConsoleCommand[]> {
    const limitNum: number = limit ? parseInt(limit, 10) : 20;
    return this.consoleService.getHistory(clusterId, limitNum);
  }
}
