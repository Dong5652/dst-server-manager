import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq } from 'drizzle-orm';
import type { WorldConfig, UpdateWorldConfigRequest } from '@shared/api.interface';
import { dstWorldConfig } from '@server/database/schema';

type WorldConfigExtraOptions = WorldConfig['extraOptions'];

@Injectable()
export class WorldConfigService {
  private readonly logger = new Logger(WorldConfigService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private mapConfig(row: typeof dstWorldConfig.$inferSelect): WorldConfig {
    const extraRaw = row.extraOptions as Record<string, unknown> | null;
    const extraOptions: WorldConfigExtraOptions = {
      pauseWhenEmpty: Boolean(extraRaw?.pauseWhenEmpty),
      maxSnapshots: typeof extraRaw?.maxSnapshots === 'number' ? extraRaw.maxSnapshots : 6,
      worldSeed: typeof extraRaw?.worldSeed === 'string' ? extraRaw.worldSeed : '',
    };

    return {
      id: row.id,
      clusterId: row.clusterId,
      worldSize: row.worldSize as WorldConfig['worldSize'],
      daySeasonLength: row.daySeasonLength,
      autumnLength: row.autumnLength,
      winterLength: row.winterLength,
      springLength: row.springLength,
      summerLength: row.summerLength,
      resourceRenewal: row.resourceRenewal,
      touchStones: row.touchStones,
      startingItems: row.startingItems ?? null,
      extraOptions,
    };
  }

  async findByClusterId(clusterId: string): Promise<WorldConfig> {
    const rows = await this.db
      .select()
      .from(dstWorldConfig)
      .where(eq(dstWorldConfig.clusterId, clusterId))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('世界配置不存在');
    }

    return this.mapConfig(rows[0]);
  }

  async update(clusterId: string, dto: UpdateWorldConfigRequest): Promise<WorldConfig> {
    const existing = await this.db
      .select()
      .from(dstWorldConfig)
      .where(eq(dstWorldConfig.clusterId, clusterId))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('世界配置不存在');
    }

    const patch: Partial<typeof dstWorldConfig.$inferInsert> = {};
    if (dto.worldSize !== undefined) patch.worldSize = dto.worldSize;
    if (dto.daySeasonLength !== undefined) patch.daySeasonLength = dto.daySeasonLength;
    if (dto.autumnLength !== undefined) patch.autumnLength = dto.autumnLength;
    if (dto.winterLength !== undefined) patch.winterLength = dto.winterLength;
    if (dto.springLength !== undefined) patch.springLength = dto.springLength;
    if (dto.summerLength !== undefined) patch.summerLength = dto.summerLength;
    if (dto.resourceRenewal !== undefined) patch.resourceRenewal = dto.resourceRenewal;
    if (dto.touchStones !== undefined) patch.touchStones = dto.touchStones;
    if (dto.startingItems !== undefined) patch.startingItems = dto.startingItems;

    if (dto.extraOptions !== undefined) {
      const currentRaw = existing[0].extraOptions as Record<string, unknown> | null;
      const merged: WorldConfigExtraOptions = {
        pauseWhenEmpty:
          dto.extraOptions.pauseWhenEmpty !== undefined
            ? dto.extraOptions.pauseWhenEmpty
            : Boolean(currentRaw?.pauseWhenEmpty),
        maxSnapshots:
          dto.extraOptions.maxSnapshots !== undefined
            ? dto.extraOptions.maxSnapshots
            : (typeof currentRaw?.maxSnapshots === 'number' ? currentRaw.maxSnapshots : 6),
        worldSeed:
          dto.extraOptions.worldSeed !== undefined
            ? dto.extraOptions.worldSeed
            : (typeof currentRaw?.worldSeed === 'string' ? currentRaw.worldSeed : ''),
      };
      patch.extraOptions = merged;
    }

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    await this.db
      .update(dstWorldConfig)
      .set(patch)
      .where(eq(dstWorldConfig.clusterId, clusterId));

    this.logger.log(`更新世界配置: clusterId=${clusterId}`);
    return this.findByClusterId(clusterId);
  }
}
