import { Module } from '@nestjs/common';
import { WorldConfigController } from './world-config.controller';
import { WorldConfigService } from './world-config.service';

@Module({
  controllers: [WorldConfigController],
  providers: [WorldConfigService],
  exports: [WorldConfigService],
})
export class WorldConfigModule {}
