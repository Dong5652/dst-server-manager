import { Controller, Get, Put, Param, Body } from '@nestjs/common';
import { WorldConfigService } from './world-config.service';
import type { WorldConfig, UpdateWorldConfigRequest } from '@shared/api.interface';

@Controller('api/world-config')
export class WorldConfigController {
  constructor(private readonly worldConfigService: WorldConfigService) {}

  @Get(':clusterId')
  async findOne(@Param('clusterId') clusterId: string): Promise<WorldConfig> {
    return this.worldConfigService.findByClusterId(clusterId);
  }

  @Put(':clusterId')
  async update(
    @Param('clusterId') clusterId: string,
    @Body() dto: UpdateWorldConfigRequest,
  ): Promise<WorldConfig> {
    return this.worldConfigService.update(clusterId, dto);
  }
}
