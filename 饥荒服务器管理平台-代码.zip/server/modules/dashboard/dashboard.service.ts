import { Injectable, Inject, Logger } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, count, desc, sql, and } from 'drizzle-orm';
import {
  dstClusters,
  dstPlayers,
  dstMods,
  dstServerLogs,
} from '@server/database/schema';
import type { DashboardStats, ServerLog } from '@shared/api.interface';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  private toServerLogDto(
    row: typeof dstServerLogs.$inferSelect,
  ): ServerLog {
    return {
      id: row.id,
      clusterId: row.clusterId,
      serverType: (row.serverType as 'master' | 'caves') ?? 'master',
      logLevel:
        (row.logLevel as 'info' | 'warn' | 'error' | 'debug') ?? 'info',
      message: row.message,
      source: row.source ?? null,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async getStats(): Promise<DashboardStats> {
    this.logger.log('获取仪表盘统计数据');

    // 1. 集群总数
    const totalClustersResult = await this.db
      .select({ count: count() })
      .from(dstClusters);
    const totalClusters = Number(totalClustersResult[0]?.count ?? 0);

    // 2. 运行中的集群数
    const runningClustersResult = await this.db
      .select({ count: count() })
      .from(dstClusters)
      .where(eq(dstClusters.status, 'running'));
    const runningClusters = Number(runningClustersResult[0]?.count ?? 0);

    // 3. 所有在线玩家总数
    const onlinePlayersResult = await this.db
      .select({ count: count() })
      .from(dstPlayers)
      .where(eq(dstPlayers.isOnline, true));
    const totalOnlinePlayers = Number(onlinePlayersResult[0]?.count ?? 0);

    // 4. Mod 总数
    const totalModsResult = await this.db
      .select({ count: count() })
      .from(dstMods);
    const totalMods = Number(totalModsResult[0]?.count ?? 0);

    // 5. 最近 10 条日志
    const recentLogsRows = await this.db
      .select()
      .from(dstServerLogs)
      .orderBy(desc(dstServerLogs.createdAt))
      .limit(10);
    const recentLogs: ServerLog[] = recentLogsRows.map((row) =>
      this.toServerLogDto(row),
    );

    // 6. 各集群状态列表（含在线人数）
    const clusters = await this.db
      .select({
        id: dstClusters.id,
        name: dstClusters.name,
        status: dstClusters.status,
      })
      .from(dstClusters)
      .orderBy(dstClusters.createdAt);

    // 收集集群 ID，批量统计在线玩家数
    const clusterIds = clusters.map((c) => c.id);
    let onlineCountsByCluster: Map<string, number> = new Map();

    if (clusterIds.length > 0) {
      const onlineCounts = await this.db
        .select({
          clusterId: dstPlayers.clusterId,
          count: count(),
        })
        .from(dstPlayers)
        .where(eq(dstPlayers.isOnline, true))
        .groupBy(dstPlayers.clusterId);

      onlineCountsByCluster = new Map(
        onlineCounts.map((row) => [row.clusterId, Number(row.count)]),
      );
    }

    const clusterStatuses = clusters.map((cluster) => ({
      id: cluster.id,
      name: cluster.name,
      status: cluster.status,
      onlineCount: onlineCountsByCluster.get(cluster.id) ?? 0,
    }));

    return {
      totalClusters,
      runningClusters,
      totalOnlinePlayers,
      totalMods,
      recentLogs,
      clusterStatuses,
    };
  }
}
