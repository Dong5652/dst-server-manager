import { Injectable, Inject, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq } from 'drizzle-orm';
import { dstSystemSettings } from '@server/database/schema';
import type { SystemSetting, BackupEntry, CreateBackupResponse } from '@shared/api.interface';

@Injectable()
export class SettingsService {
  private readonly logger = new Logger(SettingsService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getAllSettings(): Promise<SystemSetting[]> {
    try {
      const rows = await this.db.select().from(dstSystemSettings);

      return rows.map((row) => ({
        id: row.id,
        settingKey: row.settingKey,
        settingValue: row.settingValue,
        settingType: row.settingType as 'string' | 'number' | 'boolean',
        description: row.description,
      }));
    } catch (error) {
      this.logger.error(`获取系统设置失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async getSettingByKey(key: string): Promise<SystemSetting> {
    try {
      const rows = await this.db
        .select()
        .from(dstSystemSettings)
        .where(eq(dstSystemSettings.settingKey, key));

      if (rows.length === 0) {
        throw new NotFoundException(`设置项 ${key} 不存在`);
      }

      const row = rows[0];
      return {
        id: row.id,
        settingKey: row.settingKey,
        settingValue: row.settingValue,
        settingType: row.settingType as 'string' | 'number' | 'boolean',
        description: row.description,
      };
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error(`获取设置项失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async updateSetting(key: string, value: string): Promise<SystemSetting> {
    if (value === undefined) {
      throw new BadRequestException('value 不能为空');
    }

    try {
      const updated = await this.db
        .update(dstSystemSettings)
        .set({ settingValue: value })
        .where(eq(dstSystemSettings.settingKey, key))
        .returning();

      if (updated.length === 0) {
        throw new NotFoundException(`设置项 ${key} 不存在`);
      }

      const row = updated[0];
      return {
        id: row.id,
        settingKey: row.settingKey,
        settingValue: row.settingValue,
        settingType: row.settingType as 'string' | 'number' | 'boolean',
        description: row.description,
      };
    } catch (error) {
      if (error instanceof NotFoundException || error instanceof BadRequestException) throw error;
      this.logger.error(`更新设置项失败: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  createBackup(): CreateBackupResponse {
    const now: Date = new Date();
    const pad = (n: number): string => n.toString().padStart(2, '0');
    const backupName: string = `backup_${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;

    this.logger.log(`创建备份: ${backupName}`);

    return {
      success: true,
      backupName,
    };
  }

  getBackups(): BackupEntry[] {
    const now: number = Date.now();
    const backups: BackupEntry[] = [
      {
        name: 'backup_20240901_120000',
        size: 15728640,
        createdAt: new Date(now - 2 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        name: 'backup_20240830_030000',
        size: 14680064,
        createdAt: new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        name: 'backup_20240827_030000',
        size: 13631488,
        createdAt: new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        name: 'backup_20240824_030000',
        size: 12582912,
        createdAt: new Date(now - 10 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ];

    return backups;
  }
}
