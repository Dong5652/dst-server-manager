import { Controller, Get, Put, Post, Param, Body } from '@nestjs/common';
import { SettingsService } from './settings.service';
import type { SystemSetting, BackupEntry, CreateBackupResponse } from '@shared/api.interface';

@Controller('api/settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) {}

  @Get()
  async getAllSettings(): Promise<SystemSetting[]> {
    return this.settingsService.getAllSettings();
  }

  @Get('backups')
  async getBackups(): Promise<BackupEntry[]> {
    return this.settingsService.getBackups();
  }

  @Get(':key')
  async getSetting(@Param('key') key: string): Promise<SystemSetting> {
    return this.settingsService.getSettingByKey(key);
  }

  @Put(':key')
  async updateSetting(
    @Param('key') key: string,
    @Body() body: { value: string },
  ): Promise<SystemSetting> {
    return this.settingsService.updateSetting(key, body.value);
  }

  @Post('backup/create')
  async createBackup(): Promise<CreateBackupResponse> {
    return this.settingsService.createBackup();
  }
}
