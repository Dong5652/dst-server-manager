/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { bigint, boolean, foreignKey, index, integer, jsonb, pgTable, text, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const dstSystemSettings = pgTable("dst_system_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  settingKey: varchar("setting_key", { length: 100 }).notNull().unique(),
  settingValue: text("setting_value"),
  settingType: varchar("setting_type", { length: 20 }).notNull().default('string'),
  description: varchar("description", { length: 255 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("dst_system_settings_setting_key_key").on(table.settingKey),
]);

export const dstMonitoringStats = pgTable("dst_monitoring_stats", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  onlineCount: integer("online_count").notNull().default(0),
  memoryMb: integer("memory_mb").notNull().default(0),
  cpuPercent: integer("cpu_percent").default(0),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_monitoring_cluster_time").on(table.clusterId, table.createdAt),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_monitoring_stats_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstServerLogs = pgTable("dst_server_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  serverType: varchar("server_type", { length: 20 }).notNull().default('master'),
  logLevel: varchar("log_level", { length: 20 }).notNull().default('info'),
  message: text("message").notNull(),
  source: varchar("source", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_server_logs_cluster_level").on(table.clusterId, table.logLevel),
  index("idx_dst_server_logs_created_at").on(table.createdAt),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_server_logs_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstConsoleCommands = pgTable("dst_console_commands", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  command: text("command").notNull(),
  result: text("result"),
  executedBy: varchar("executed_by", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_console_cluster_id").on(table.clusterId),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_console_commands_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstPlayerLists = pgTable("dst_player_lists", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  listType: varchar("list_type", { length: 20 }).notNull(),
  kleiId: varchar("klei_id", { length: 100 }).notNull(),
  playerName: varchar("player_name", { length: 255 }),
  reason: text("reason"),
  addedAt: customTimestamptz("added_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_player_lists_cluster_type").on(table.clusterId, table.listType),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_player_lists_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstPlayers = pgTable("dst_players", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  kleiId: varchar("klei_id", { length: 100 }).notNull(),
  playerName: varchar("player_name", { length: 255 }).notNull(),
  isOnline: boolean("is_online").notNull().default(false),
  lastJoinAt: customTimestamptz("last_join_at", { precision: 3 }),
  playtimeSeconds: bigint("playtime_seconds", { mode: 'number' }).notNull().default(0),
  characterUsed: varchar("character_used", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_players_cluster_id").on(table.clusterId),
  uniqueIndex("idx_dst_players_cluster_klei").on(table.clusterId, table.kleiId),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_players_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstMods = pgTable("dst_mods", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  workshopId: varchar("workshop_id", { length: 50 }).notNull(),
  modName: varchar("mod_name", { length: 255 }).notNull(),
  description: text("description"),
  author: varchar("author", { length: 255 }),
  enabled: boolean("enabled").notNull().default(false),
  priority: integer("priority").notNull().default(0),
  /**
   * @type { options: Array<{ name: string, value: string | number | boolean }> }
   */
  modConfig: jsonb("mod_config").default('{}'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_mods_cluster_id").on(table.clusterId),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_mods_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstWorldConfig = pgTable("dst_world_config", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull().unique(),
  worldSize: varchar("world_size", { length: 20 }).notNull().default('default'),
  daySeasonLength: integer("day_season_length").notNull().default(20),
  autumnLength: integer("autumn_length").notNull().default(20),
  winterLength: integer("winter_length").notNull().default(15),
  springLength: integer("spring_length").notNull().default(20),
  summerLength: integer("summer_length").notNull().default(15),
  resourceRenewal: boolean("resource_renewal").notNull().default(true),
  touchStones: integer("touch_stones").notNull().default(4),
  startingItems: varchar("starting_items", { length: 255 }),
  /**
   * @type { pause_when_empty: boolean, max_snapshots: number, world_seed: string }
   */
  extraOptions: jsonb("extra_options").default('{}'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("dst_world_config_cluster_id_key").on(table.clusterId),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_world_config_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstServers = pgTable("dst_servers", {
  id: uuid("id").primaryKey().defaultRandom(),
  clusterId: uuid("cluster_id").notNull(),
  serverType: varchar("server_type", { length: 20 }).notNull().default('master'),
  port: integer("port").notNull().default(10999),
  pid: integer("pid"),
  status: varchar("status", { length: 20 }).notNull().default('stopped'),
  memoryMb: integer("memory_mb").default(0),
  lastHeartbeat: customTimestamptz("last_heartbeat", { precision: 3 }),
  startedAt: customTimestamptz("started_at", { precision: 3 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_dst_servers_cluster_id").on(table.clusterId),
  foreignKey({
    columns: [table.clusterId],
    foreignColumns: [dstClusters.id],
    name: "dst_servers_cluster_id_fkey",
  }).onDelete("cascade"),
]);

export const dstClusters = pgTable("dst_clusters", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 20 }).notNull().default('stopped'),
  gameMode: varchar("game_mode", { length: 20 }).notNull().default('survival'),
  maxPlayers: integer("max_players").notNull().default(6),
  hasCaves: boolean("has_caves").notNull().default(true),
  steamToken: varchar("steam_token", { length: 255 }),
  clusterToken: varchar("cluster_token", { length: 255 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
});

export const dstUsers = pgTable("dst_users", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default('user'),
  displayName: varchar("display_name", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("dst_users_username_key").on(table.username),
]);

// table aliases
export const dstClustersTable = dstClusters;
export const dstConsoleCommandsTable = dstConsoleCommands;
export const dstModsTable = dstMods;
export const dstMonitoringStatsTable = dstMonitoringStats;
export const dstPlayerListsTable = dstPlayerLists;
export const dstPlayersTable = dstPlayers;
export const dstServerLogsTable = dstServerLogs;
export const dstServersTable = dstServers;
export const dstSystemSettingsTable = dstSystemSettings;
export const dstUsersTable = dstUsers;
export const dstWorldConfigTable = dstWorldConfig;
