import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { AuthModule } from './modules/auth/auth.module';
import { ClustersModule } from './modules/clusters/clusters.module';
import { WorldConfigModule } from './modules/world-config/world-config.module';
import { ModsModule } from './modules/mods/mods.module';
import { PlayersModule } from './modules/players/players.module';
import { ConsoleModule } from './modules/console/console.module';
import { LogsModule } from './modules/logs/logs.module';
import { MonitoringModule } from './modules/monitoring/monitoring.module';
import { SettingsModule } from './modules/settings/settings.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';

@Module({
  imports: [
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    AuthModule,
    DashboardModule,
    ClustersModule,
    WorldConfigModule,
    ModsModule,
    PlayersModule,
    ConsoleModule,
    LogsModule,
    MonitoringModule,
    SettingsModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
