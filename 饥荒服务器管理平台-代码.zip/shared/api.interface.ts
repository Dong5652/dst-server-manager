// 前后端共享的类型定义
// 所有接口请求/响应类型都在此定义，前后端统一使用

export interface User {
  id: string;
  username: string;
  role: 'admin' | 'user';
  displayName: string | null;
  createdAt: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  user: User;
  token: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  displayName?: string;
}

export interface Cluster {
  id: string;
  name: string;
  description: string | null;
  status: 'running' | 'stopped' | 'starting' | 'stopping' | 'error';
  gameMode: 'survival' | 'endless' | 'wilderness';
  maxPlayers: number;
  hasCaves: boolean;
  steamToken: string | null;
  clusterToken: string | null;
  createdAt: string;
  servers?: Server[];
}

export interface Server {
  id: string;
  clusterId: string;
  serverType: 'master' | 'caves';
  port: number;
  pid: number | null;
  status: 'running' | 'stopped' | 'starting' | 'stopping' | 'error';
  memoryMb: number;
  lastHeartbeat: string | null;
  startedAt: string | null;
}

export interface CreateClusterRequest {
  name: string;
  description?: string;
  gameMode: 'survival' | 'endless' | 'wilderness';
  maxPlayers: number;
  hasCaves: boolean;
  clusterToken?: string;
}

export interface UpdateClusterRequest {
  name?: string;
  description?: string;
  gameMode?: 'survival' | 'endless' | 'wilderness';
  maxPlayers?: number;
  hasCaves?: boolean;
  clusterToken?: string;
}

export interface ClusterListResponse {
  items: Cluster[];
  total: number;
}

export interface WorldConfig {
  id: string;
  clusterId: string;
  worldSize: 'tiny' | 'small' | 'default' | 'medium' | 'large' | 'huge';
  daySeasonLength: number;
  autumnLength: number;
  winterLength: number;
  springLength: number;
  summerLength: number;
  resourceRenewal: boolean;
  touchStones: number;
  startingItems: string | null;
  extraOptions: {
    pauseWhenEmpty: boolean;
    maxSnapshots: number;
    worldSeed: string;
  };
}

export interface UpdateWorldConfigRequest {
  worldSize?: 'tiny' | 'small' | 'default' | 'medium' | 'large' | 'huge';
  daySeasonLength?: number;
  autumnLength?: number;
  winterLength?: number;
  springLength?: number;
  summerLength?: number;
  resourceRenewal?: boolean;
  touchStones?: number;
  startingItems?: string;
  extraOptions?: {
    pauseWhenEmpty?: boolean;
    maxSnapshots?: number;
    worldSeed?: string;
  };
}

export interface Mod {
  id: string;
  clusterId: string;
  workshopId: string;
  modName: string;
  description: string | null;
  author: string | null;
  enabled: boolean;
  priority: number;
  modConfig: {
    options: Array<{ name: string; value: string | number | boolean }>;
  };
  createdAt: string;
}

export interface AddModRequest {
  clusterId: string;
  workshopId: string;
  modName: string;
  description?: string;
  author?: string;
}

export interface UpdateModRequest {
  enabled?: boolean;
  priority?: number;
  modConfig?: {
    options: Array<{ name: string; value: string | number | boolean }>;
  };
}

export interface Player {
  id: string;
  clusterId: string;
  kleiId: string;
  playerName: string;
  isOnline: boolean;
  lastJoinAt: string | null;
  playtimeSeconds: number;
  characterUsed: string | null;
}

export interface PlayerListEntry {
  id: string;
  clusterId: string;
  listType: 'admin' | 'whitelist' | 'ban';
  kleiId: string;
  playerName: string | null;
  reason: string | null;
  addedAt: string;
}

export interface AddPlayerListRequest {
  clusterId: string;
  listType: 'admin' | 'whitelist' | 'ban';
  kleiId: string;
  playerName?: string;
  reason?: string;
}

export interface ConsoleCommand {
  id: string;
  clusterId: string;
  command: string;
  result: string | null;
  executedBy: string | null;
  createdAt: string;
}

export interface ExecuteCommandRequest {
  clusterId: string;
  command: string;
}

export interface ServerLog {
  id: string;
  clusterId: string;
  serverType: 'master' | 'caves';
  logLevel: 'info' | 'warn' | 'error' | 'debug';
  message: string;
  source: string | null;
  createdAt: string;
}

export interface MonitoringStat {
  id: string;
  clusterId: string;
  onlineCount: number;
  memoryMb: number;
  cpuPercent: number | null;
  createdAt: string;
}

export interface MonitoringOverview {
  onlineCount: number;
  memoryMb: number;
  cpuPercent: number;
  uptimeSeconds: number;
  history: MonitoringStat[];
}

export interface SystemSetting {
  id: string;
  settingKey: string;
  settingValue: string | null;
  settingType: 'string' | 'number' | 'boolean';
  description: string | null;
}

export interface BackupEntry {
  name: string;
  size: number;
  createdAt: string;
}

export interface CreateBackupResponse {
  success: boolean;
  backupName: string;
}

export interface DashboardStats {
  totalClusters: number;
  runningClusters: number;
  totalOnlinePlayers: number;
  totalMods: number;
  recentLogs: ServerLog[];
  clusterStatuses: Array<{ id: string; name: string; status: string; onlineCount: number }>;
}
